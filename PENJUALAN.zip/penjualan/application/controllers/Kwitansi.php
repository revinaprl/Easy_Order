<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Kwitansi extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Kwitansi_model');
		$this->load->model('No_urut');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'kwitansi/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'kwitansi/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'kwitansi/index.html';
            $config['first_url'] = base_url() . 'kwitansi/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Kwitansi_model->total_rows($q);
        $kwitansi = $this->Kwitansi_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'kwitansi_data' => $kwitansi,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
            'konten' => 'kwitansi/kwitansi_list',
            'judul' => 'Data Kwitansi',
        );
        $this->load->view('v_index', $data);
    }

     public function cek_kwitansi()
    {
        $kode_order = $this->input->post('kode_order');
        $cek = $this->db->query("SELECT * FROM transaksi WHERE kode_order='$kode_order'")->row();
        $data = array(
            'id_order' => $cek->id_order,
            'kode_kwitansi' => $cek->kode_kwitansi,
            'nama_penerima' => $cek->nama_penerima,
            'banyak_uang' => $cek->banyak_uang,
            'total_bayar' => $cek->total_bayar,
        );
        echo json_encode($data);
    }

     public function create_action() 
    {
        $this->_rules();

            $data = array(
        'kode_order' => $this->input->post('kode_order'),
        'kode_kwitansi' => $this->input->post('kode_kwitansi'),
        'nama_penerima' => $this->input->post('nama_penerima'),
        'banyak_uang' => $this->input->post('banyak_uang'),
        'total_bayar' => $this->input->post('total_bayar'),
    
            );

            $this->Kwitansi_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('kwitansi'));
       
    }

    public function cetak_kwitansi()
    {
        $kode_kwitansi = $_GET['kode_kwitansi'];
        $data = array(
            'data' => $this->db->query("SELECT * from kwitansi WHERE kode_kwitansi = '$kode_kwitansi'"),
            );
        $this->load->view('cetak_kwitansi',$data);
    }

    public function detail_kwitansi()
    {
        $kode_kwitansi = $_GET['kode_kwitansi'];
        $data = array(
            'konten' => 'detail_kwitansi',
            'judul' => 'Detail Kwitansi',
            'data' => $this->db->query("SELECT * from kwitansi WHERE kode_kwitansi = '$kode_kwitansi'"),
        );
        $this->load->view('v_index',$data);
    }

    public function _rules() 
    {
    $this->form_validation->set_rules('kode_kwitansi', 'kode kwitansi', 'trim|required');
	$this->form_validation->set_rules('kode_order', 'kode_order invoice', 'trim|required');
    $this->form_validation->set_rules('nama_penerima', 'nama penerima', 'trim|required');
	$this->form_validation->set_rules('banyak_uang', 'banyak uang', 'trim|required');
    $this->form_validation->set_rules('jumlah_uang', 'jumlah uang', 'trim|required');
    $this->form_validation->set_rules('id_kwitansi', 'id_kwitansi', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}
