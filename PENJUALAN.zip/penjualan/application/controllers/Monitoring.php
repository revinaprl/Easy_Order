<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Monitoring extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('Monitoring_model');
        $this->load->model('No_urut');
        $this->load->library('form_validation');
        $this->load->model('upload_pembayaran');

    }

    public function index()
    {
        $data['berkas'] = $this->db->get('monitoring');
        $q = urldecode($this->input->get('s', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'monitoring/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'monitoring/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'monitoring/index.html';
            $config['first_url'] = base_url() . 'monitoring/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Monitoring_model->total_rows($q);
        $monitoring = $this->Monitoring_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'monitoring_data' => $monitoring,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
            'konten' => 'monitoring/monitoring_list',
            'judul' => 'Data Monitoring',
            'data1' => 'proses',
            'data1' => 'selesai'
        );
        $this->load->view('v_index', $data);
    }

    public function cek_monitoring()
    {
        $kode_order = $this->input->post('kode_order');
        $cek = $this->db->query("SELECT * FROM t.*, WHERE kode_order ='$kode_order'")->row();
        $data = array(
            'id_order' => $cek->id_order,
            'kode_surat' => $cek->kode_surat,
        );
        echo json_encode($data);
    }

 
   
    public function create_action() 
    {
         $this->_rules();
        $config['upload_path']   = './uploads/';
        $config['allowed_types'] = 'jpg|png|jpeg|pdf';
        $config['max_size']  = '2048';
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('berkas'))
        {
                $error = array('error' => $this->upload->display_errors());
                $this->load->view('v_index', $error);
        }
        else
        {
               $data = array(

        'kode_order' => $this->input->post('kode_order',TRUE),
        'kode_surat' => $this->input->post('kode_surat',TRUE),
        'status' => $this->input->post('status'),
        'berkas' => $this->upload->data('file_name'),
       
        );
           $this->Monitoring_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('monitoring'));
        }
    }

  /*  public function detail_monitoring()
    {
        $kode_monitoring = $_GET['kode_monitoring'];
        $data = array(
            'konten' => 'detail_monitoring',
            'judul' => 'Detail Monitoring',
            'data' => $this->db->query("SELECT * FROM t.*, where kode_order ='$kode_order'"),
        );
        $this->load->view('v_index',$data);
    }*/

    public function _rules() 
    {
	$this->form_validation->set_rules('kode_order', 'kode order', 'trim|required');
    $this->form_validation->set_rules('kode_surat', 'kode_surat', 'trim|required');
    $this->form_validation->set_rules('status', 'status', 'trim|required');
	$this->form_validation->set_rules('id_monitoring', 'id_monitoring', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function edit_status($id_monitoring)
    {
        $monitoring = $this->Monitoring_model->detail_monitoring($id_monitoring);
        //validasi input
    
        $i = $this->input;
        
        $data = array(
            'id_user'   => $id_user,
            'status' => $i->post('status')
        );
        $this->Monitoring_model->edit_status($data);
        $this->session->set_flashdata('selesai', 'STATUS ORDER TELAH SELESAI');
        redirect(base_url('monitoring/monitoring_list'), 'refresh');
    }

    public function proses($kode_order)
    {
        
        $data = array(
            'kode_order' => $kode_order,
            'status' => 'Proses'
        );
        $this->Monitoring_model->edit_status($data);
        
        $this->Order_model->edit_status($data);
        
        $this->session->set_flashdata('selesai', 'STATUS ORDER TELAH SELESAI');
        redirect(base_url('monitoring'), 'refresh');
    }

    public function selesai($kode_order)
    {
        // $monitoring = $this->Monitoring_model->detail_monitoring($id_monitoring);
        // $i = $this->input;
        $data = array(
            'kode_order' => $kode_order,
            'status' => 'Selesai'
        );
        // print_r($this->Monitoring_model->edit_status($data));die;
        $this->Monitoring_model->edit_status($data);
        // $this->Monitoring_model->edit_status($data);
        
            $this->Order_model->edit_status($data);
        
        $this->session->set_flashdata('proses', 'STATUS ORDER BELUM SELESAI');
        redirect(base_url('monitoring'), 'refresh');
    }

    // public function update_status()
    // {
    //     print_r('ckuaks');die;
    //     print_r($this->Monitoring_model->update_status($id));die;
        
    //     redirect(base_url('monitoring/monitoring_list'));
    // }
}

