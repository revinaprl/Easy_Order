<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Satuan extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Satuan_model');
        $this->load->model('No_urut');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'satuan/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'satuan/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'satuan/index.html';
            $config['first_url'] = base_url() . 'satuan/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Satuan_model->total_rows($q);
        $satuan = $this->Satuan_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'satuan_data' => $satuan,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
            'konten' => 'satuan/satuan_list',
            'judul' => 'Data Satuan',
        );
        $this->load->view('v_index', $data);
    }

    public function read($id) 
    {
        $row = $this->Satuan_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_satuan' => $row->id_satuan,
		'nama_satuan' => $row->nama_satuan,
	    );
            $this->load->view('satuan/satuan_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('satuan'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('satuan/create_action'),
	    'id_satuan' => set_value('id_satuan'),
	    'nama_satuan' => set_value('nama_satuan'),
        'konten' => 'satuan/satuan_form',
            'judul' => 'Data Satuan',
	);
        $this->load->view('v_index', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {

            $satuan = $this->input->post('nama_satuan',TRUE);
            $this->Satuan_model->insert($satuan);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('satuan'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Satuan_model->get_by_id($id);
        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('satuan/update_action'),
                'id_satuan' => $id,
                'nama_satuan' => $row['nama_satuan'],
                'judul' => 'Data Satuan',
                'konten' => 'satuan/satuan_form'
	           );
            $this->load->view('v_index', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('satuan'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_satuan', TRUE));
        } else {
        if ($_FILES == '') {
            
           $satuan = $this->input->post('nama_satuan',TRUE);

            $this->Satuan_model->update($this->input->post('id_satuan', TRUE), $satuan);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('satuan'));

        } else {

            $satuan = $this->input->post('nama_satuan',TRUE);

            $this->Satuan_model->update($this->input->post('id_satuan', TRUE), $satuan);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('satuan'));
        }

           
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Satuan_model->get_by_id($id);

        if ($row) {
            $this->Satuan_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('satuan'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('satuan'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('nama_satuan', 'nama satuan', 'trim|required');

	$this->form_validation->set_rules('id_satuan', 'id_satuan', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

