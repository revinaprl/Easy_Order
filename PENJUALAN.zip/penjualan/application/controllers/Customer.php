<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Customer extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Customer_model');
		$this->load->model('No_urut');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'customer/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'customer/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'customer/index.html';
            $config['first_url'] = base_url() . 'customer/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Customer_model->total_rows($q);
        $customer = $this->Customer_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'customer_data' => $customer,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
            'konten' => 'customer/customer_list',
            'judul' => 'Data Customer',
        );
        $this->load->view('v_index', $data);
    }

    public function read($id) 
    {
        $row = $this->Customer_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_customer' => $row->id_customer,
        'kode_customer' => $row->kode_customer,
		'nama_customer' => $row->nama_customer,
        'alamat' => $row->alamat,
        'email' => $row->email,
        'no_telp' => $row->no_telp,
	    );
            $this->load->view('customer/customer_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('customer'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('customer/create_action'),
	    'id_customer' => set_value('id_customer'),
        'kode_customer' => $this->No_urut->buat_kode_customer(),
        'nama_customer' => set_value('nama_customer'),
        'alamat' => set_value('alamat'),
        'email' => set_value('email'),
        'no_telp' => set_value('no_telp'),
        'konten' => 'customer/customer_form',
            'judul' => 'Data Customer',
	);
        $this->load->view('v_index', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'kode_customer' => $this->input->post('kode_customer',TRUE),
        'nama_customer' => $this->input->post('nama_customer',TRUE),
        'alamat' => $this->input->post('alamat',TRUE),
        'email' => $this->input->post('email',TRUE),
        'no_telp' => $this->input->post('no_telp',TRUE),
	    );

            $this->Customer_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('customer'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Customer_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('customer/update_action'),
		'id_customer' => set_value('id_customer', $row->id_customer),
        'kode_customer' => set_value('kode_customer', $row->kode_customer),
        'nama_customer' => set_value('nama_customer', $row->nama_customer),
        'alamat' => set_value('alamat', $row->alamat),
        'email' => set_value('email', $row->email),
        'no_telp' => set_value('no_telp', $row->no_telp),
        'konten' => 'customer/customer_form',
            'judul' => 'Data Customer',
	    );
            $this->load->view('v_index', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('customer'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_customer', TRUE));
        } else {
            $data = array(
		'kode_customer' => $this->input->post('kode_customer',TRUE),
        'nama_customer' => $this->input->post('nama_customer',TRUE),
       'alamat' => $this->input->post('alamat',TRUE),
        'email' => $this->input->post('email',TRUE),
        'no_telp' => $this->input->post('no_telp',TRUE),
	    );

            $this->Customer_model->update($this->input->post('id_customer', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('customer'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Customer_model->get_by_id($id);

        if ($row) {
            $this->Customer_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('customer'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('customer'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('kode_customer', 'kode_customer', 'trim|required');
    $this->form_validation->set_rules('nama_customer', 'nama_customer', 'trim|required');
    $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');
	$this->form_validation->set_rules('email', 'Email', 'trim|required');
    $this->form_validation->set_rules('no_telp', 'no_telp', 'trim|required');
    $this->form_validation->set_rules('id_customer', 'id_customer', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}
