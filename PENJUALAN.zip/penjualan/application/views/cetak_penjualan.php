<!DOCTYPE html>
<html>
<head>
	<base href="<?php echo base_url() ?>">
	<title>Cetak Order</title>
	<link rel="stylesheet" type="text/css" href="assets/bootflat-admin/css/bootstrap.min.css">
</head>
<body onload="window.print();">
	<div class="container">
	<center>
		<table>
			<tr>
				<td width="70px" rowspan="3"><img src="<?php echo base_url('assets/img/sap.png') ?>" width='50px'></td>
				<td style="text-align: center;"><h4>CV. SURYA ANUGERAH PLASTIK</h4></td>

			</tr>
			<tr>
				
				<td style="text-align: center;"><p>Jl. Cilalawak, Purwakarta</p></td>
			</tr>
			<tr>
				
				<td style="text-align: center;"><p>Telp. (0821)-612673</p></td>
			</tr>
			
		</table>
		<p style="text-align: right;"><b>ORDER</b></p>
	</center>
	<hr style=" height: 2px; color:red;background-color:black">
	<?php 
	$rs = $data->row();
	 ?>
	<div class="row">
		<div class="col-md-12">
			<table class="table">
				<tr>
					<th>Kode Order</th>
					<th>:</th>
					<td><?php echo $rs->kode_order; ?></td>
					<th>Customer</th>
					<th>:</th>
					<td><?php echo $rs->nama_customer; ?></td>
				</tr>
				<tr>
					<th>Tanggal Order</th>
					<th>:</th>
					<td><?php echo $rs->tgl_order; ?></td>
					<!-- <th>Total Bayar</th>
					<th>:</th>
					<td>Rp. <?php echo number_format ($rs->total_bayar); ?></td> -->
				</tr>
			</table>
		</div>
		<div class="col-md-12">
			<table class="table table-bordered" style="margin-bottom: 10px" >
				<thead>
					<tr>
						<th>No.</th>
						<th>Kode Barang</th>
						<!-- <th>Kategori</th> -->
						<th>Nama Barang</th>
						<!-- <th>Customer</th> -->
						<th>Qty</th>
						<th>Satuan</th>
						<th>Harga Barang</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$sql = $this->db->query("SELECT  b.kode_barang as bkode_barang, b.nama_barang as bnama_barang, dt.qty as dt_qty, dt.satuan as dt_satuan, b.harga as bharga , t.total_bayar as t_total_bayar
				FROM transaksi t JOIN detail_transaksi dt ON t.kode_order = dt.kode_order JOIN barang b ON dt.kode_barang = b.kode_barang WHERE dt.kode_order ='$rs->kode_order'");
					$no = 1;
					foreach ($sql->result() as $row) {
					 ?>
					<tr>
						<td><?php echo $no++; ?></td>
						<td><?php echo $row->bkode_barang; ?></td>
						<td><?php echo $row->bnama_barang; ?></td>
						<td><?php echo $row->dt_qty; ?></td>
						<td><?php echo $row->dt_satuan; ?></td>
						<td><?php echo $row->bharga; ?></td>
					</tr>
					<?php } ?>
					<tr>
						<td colspan="5"><b>Total Harga</b></td>
						<td>Rp. <?php

              
                    $total_harga =  $row->dt_qty*$row->bharga;
                        
                    echo number_format($total_harga);

                    ?>
					</tr>
					<tr>
						<td colspan="5"><b>PPN (10%)</b></td>
						
						<td> Rp.
						<?php 
						$ppn = 0.1 * $total_harga;
						$setelahppn = $total_harga+$ppn;
						
						echo number_format($setelahppn);

						?>
					</tr>
					 <tr>
						<td colspan="5"><b>Diskon</b></td>
						<td>
							Rp.
						<?php 
						$diskon = 0;
						if ($setelahppn >= 100000) {
							$diskon = 0.1 * $setelahppn;
						} else {
							$diskon = 0;
						 
						}
						echo number_format($diskon);

						?>
						</td>
					</tr>
					<tr>
						<td colspan="5"><b>Total Bayar</b></td>
						<td>Rp. <?php echo number_format($setelahppn-$diskon) ?></td>
					</tr>
					
				</tbody>
			</table>
<div class="col-md-5 col-md-offset-7" style="margin-top: 200px;">
		<table class="table" style="margin-bottom: 10px; border-width: 3px;" border="1">
			<tr>
				<th style="width: 40px;">Customer</th>
				<th style="width: 40px;">Dibuat</th>
				<th style="width: 40px;">Diperiksa</th>
				<th style="width: 40px;">Disetujui</th>
			</tr>
			<tr>
				<td style="height: 100px;"></td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
		</table>
	</div>
		</div>
	</div>
</div>
</body>
</html>