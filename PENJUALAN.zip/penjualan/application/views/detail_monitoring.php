<?php 
$monitoring = $data->row();
 ?>
<div class="row">
	<div class="col-md-12">
		<table class="table">
			<tr>
				<th>Nama Customer</th>
				<th>:</th>
				<td><?php echo $rs->kode_customer; ?></td>
			
			</tr>
		</table>
	</div>
	<div class="col-md-12">
		<table class="table table-bordered" style="margin-bottom: 10px" >
			<thead>
				<tr>
					<th>No.</th>
        <th>Kode Monitoring</th>
        <th>Kode Order</th>
        <th>Kode Customer</th>
        <th>Kode Barang</th>
        <th>Tanggal Order</th>
        <th>Tanggal Kirim</th>
        <th>Qty Order</th>
        <th>Qty Kirim</th>
        <th>Status</th>
            </tr>
			</thead>
			<tbody>
		
			<tr>
					<td><?php echo $no++; ?></td>	
            <td><?php echo $monitoring->kode_monitoring ?></td>
            <td><?php echo $monitoring->kode_order ?></td>
            <td><?php echo $monitoring->kode_customer ?></td>
            <td><?php echo $monitoring->kode_barang ?></td>
             <td><?php echo $monitoring->tgl_order ?></td>
            <td><?php echo $monitoring->tgl_kirim ?></td>
            <td><?php echo $monitoring->qty_order ?></td>
            <td><?php echo $monitoring->qty_kirim ?></td>
            <td><?php echo $monitoring->status ?></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>