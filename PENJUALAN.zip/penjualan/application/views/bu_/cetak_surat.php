<!DOCTYPE html>
<html>
<head>
	<base href="<?php echo base_url() ?>">
	<title>Cetak Surat Jalan</title>
	<link rel="stylesheet" type="text/css" href="assets/bootflat-admin/css/bootstrap.min.css">
</head>
<body >
	<div class="container">
	<center>
		<h4>CV. SURYA ANUGERAH PLASTIK</h4>
		<p>Jl. Cilalawak, Purwakarta</p>
		<p>Telp. (0821)-612673</p>
	</center>
	<div class="row">
		<div class="col-md-12">
			<table class="table">
				<?php
					foreach ($data as $data_cetak)
					{
						?>
						<tr>
							<th>Kode Surat</th>
							<th>:</th>
							<td><?php echo $data_cetak->kode_surat; ?></td>
							<th>Kode Order</th>
							<th>:</th>
							<td><?php echo $data_cetak->kode_order; ?></td> 
						</tr>
						<tr>
							<th>Alamat</th>
							<th>:</th>
							<td><?php echo $data_cetak->alamat; ?></td> 
							<th>No Telp</th>
							<th>:</th>
							<td><?php echo $data_cetak->no_telp; ?></td> 
						</tr>
						<?php
					}
				?>
						
			</table>
		</div>
		<!-- <div class="col-md-12">
			<table class="table table-bordered" style="margin-bottom: 10px" >
				<thead>
					<tr>
						<th>No.</th>
						<th>Kode Surat</th>
						<th>Nama Barang</th>
						<th>No Kendaraan</th>
						<th>Tanggal Kirim</th>
						<th>Qty Order</th>
						<th>Qty Kirim</th>
						<th>Sisa Order</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$sql = $this->db->query("SELECT * FROM detail_surat as a, order as s where a.kode_order='$rs->kode_order");
					$no = 1;
					foreach ($sql->result() as $row) {
					 ?>
					<tr>
						<td><?php echo $no++; ?></td>
						<td><?php echo $row->kode_surat; ?></td>
						<td><?php echo $row->nama_barang; ?></td>
						<td><?php echo $row->no_kendaraan; ?></td>
						<td><?php echo $row->tgl_kirim; ?></td>
						<td><?php echo $row->qty_order; ?></td>
						<td><?php echo $row->qty_kirim; ?></td>
						<td><?php echo $row->sisa_order; ?></td>
					</tr>
				</tbody>
			</table>

			<div style="text-align: right;">
				<p>Purwakarta, <?php echo date('d/m/Y') ?></p>
				<br><br><br><br><br>
				<p>Ucu Sanjaya</p>
			</div>
		</div> -->
	</div>
</div>


<script src='assets/jspdf.debug.js'></script>
	<script src='assets/html2pdf.js'></script>
	<script>
		var pdf = new jsPDF('l', 'pt', 'A4');
		var canvas = pdf.canvas;
		var width = 1200;
		canvas.width=8.5*72;
		document.body.style.width=width + "px";

		html2canvas(document.body, {
		    canvas:canvas,
		    onrendered: function(canvas) {
		        var iframe = document.createElement('iframe');
		        iframe.setAttribute('style', 'position:absolute;top:0;right:0;height:100%; width:100%');
		        document.body.appendChild(iframe);
		        iframe.src = pdf.output('datauristring');

		       var div = document.createElement('pre');
		       div.innerText=pdf.output();
		       document.body.appendChild(div);
		    }
		});
     </script>


</body>
