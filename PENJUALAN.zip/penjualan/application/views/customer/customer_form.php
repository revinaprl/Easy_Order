<form action="<?php echo $action; ?>" method="post">
        <div class="form-group">
            <label for="varchar">Kode Customer <?php echo form_error('kode_customer') ?></label>
            <input type="text" class="form-control" name="kode_customer" id="kode_customer" placeholder="Kode Customer" value="<?php echo $kode_customer; ?>" />
        </div>
        <div class="form-group">
            <label for="varchar">Nama Customer <?php echo form_error('nama_customer') ?></label>
            <input type="text" class="form-control" name="nama_customer" id="nama_customer" placeholder="Nama Customer" value="<?php echo $nama_customer; ?>" />
        </div>
        <div class="form-group">
            <label for="varchar">Alamat <?php echo form_error('alamat') ?></label>
            <input type="text" class="form-control" name="alamat" id="alamat" placeholder="Alamat" value="<?php echo $alamat; ?>" />
        </div>
        <div class="form-group">
            <label for="varchar">Email <?php echo form_error('email') ?></label>
            <input type="text" class="form-control" name="email" id="email" placeholder="Email" value="<?php echo $email; ?>" />
        </div>
        <div class="form-group">
            <label for="varchar">No Telp <?php echo form_error('no_telp') ?></label>
            <input type="text" class="form-control" name="no_telp" id="no_telp" placeholder="No telp" value="<?php echo $no_telp; ?>" />
        </div>
        <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
        <a href="<?php echo site_url('customer') ?>" class="btn btn-default">Cancel</a>
    </form>