<div class="row">
    <div class="col-md-4">
        <a href="app/tambah_penjualan" class="btn btn-primary">Tambah Order</a>
        <!-- <a href="app/export_penjualan" target="_blank" class="btn btn-primary">Export</a> -->
        
    </div>
    
    <div class="col-md-4"></div>
    <div class="col-md-4"></div><br><br><br>
    <div class="col-md-12">
        <table class="table table-bordered" style="margin-bottom: 10px" id="example">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Kode Order</th>
                    <th>Customer</th>
                    <th>Tanggal Order</th>
                    <th>Total Bayar</th>
                    <th>Status</th>
                    <th>Status Cetak</th>
                    <th>Pilihan</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $sql = $this->db->query("SELECT t.*, t.nama_customer as cust_nama FROM transaksi t JOIN customer c ON t.nama_customer = c.kode_customer");
                $no = 1;
                foreach ($sql->result() as $row) {
                 ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo $row->kode_order; ?></td>
                    <td><?php echo $row->cust_nama; ?></td>
                    <td><?php echo $row->tgl_order; ?></td>
                    <td><?php echo number_format ($row->total_bayar); ?></td>
                    <td><?php echo $row->status_order;   ?></td>
                    <td><?php echo $row->status_cetak;   ?></td>
                    <td style="text-align:center" width="200px">
                
                        <a href="app/detail_penjualan/<?php echo $row->kode_order ?>" class="btn btn-info btn-sm">detail</a>
                       
                        <?php 
                        if ($row->status_order == 'Proses') { ?>
                        <a href="app/cetak_penjualan/<?php echo $row->kode_order ?>" target="_blank" class="btn btn-warning btn-sm" disabled>cetak</a>

                    <?php } else { ?>
                        <?php if($row->status_cetak == 'Sudah Dicetak'){?>
                              <a href="app/cetak_penjualan/<?php echo $row->kode_order ?>" target="_blank" class="btn btn-warning btn-sm" disabled>cetak</a>
                       <?php }else {?>
                                <a href="app/cetak_penjualan/<?php echo $row->kode_order ?>" target="_blank" class="btn btn-warning btn-sm" >cetak</a>
                      <?php } ?>
                        
            <?php } ?>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>