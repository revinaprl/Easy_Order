<form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data">
         <div class="form-group">
            <label for="int">Nama Satuan <?php echo form_error('nama_satuan') ?></label>
            <input type="text" class="form-control" name="nama_satuan" value="<?php echo $nama_satuan ?>" id="nama_satuan" placeholder="Nama Satuan"/>
        </div>
        <input type="hidden" name="id_satuan" value="<?php echo $id_satuan; ?>" /> 
        <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
        <a href="<?php echo site_url('satuan') ?>" class="btn btn-default">Cancel</a>
    </form>