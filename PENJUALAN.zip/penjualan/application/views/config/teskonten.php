<div class="panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title"><a href="javascript:void(0);" class="toggle-sidebar"><span class="fa fa-angle-double-left" data-toggle="offcanvas" title="Maximize Panel"></span></a> Panel Title</h3>
              </div>
              <div class="panel-body">
                <div class="content-row">
                  <h2 class="content-row-title">Panels</h2>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                          <h3 class="panel-title">Panel title</h3>
                        </div>
                        <div class="panel-body">
                          Panel content
                        </div>
                      </div>
                      <div class="panel panel-primary">
                        <div class="panel-heading">
                          <h3 class="panel-title">Panel title</h3>
                        </div>
                        <div class="panel-body">
                          Panel content
                        </div>
                      </div>
                      <div class="panel panel-success">
                        <div class="panel-heading">
                          <h3 class="panel-title">Panel title</h3>
                        </div>
                        <div class="panel-body">
                          Panel content
                        </div>
                      </div>
                      <div class="panel panel-warning">
                        <div class="panel-heading">
                          <h3 class="panel-title">Panel title</h3>
                        </div>
                        <div class="panel-body">
                          Panel content
                        </div>
                      </div>
                      <div class="panel panel-info">
                        <div class="panel-heading">
                          <h3 class="panel-title">Panel title</h3>
                        </div>
                        <div class="panel-body">
                          Panel content
                        </div>
                      </div>
                      <div class="panel panel-danger">
                        <div class="panel-heading">
                          <h3 class="panel-title">Panel title</h3>
                        </div>
                        <div class="panel-body">
                          Panel content
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="panel panel-default">
                        <div class="panel-heading">Panel heading</div>
                        <table class="table">
                          <thead>
                            <tr>
                              <th>#</th>
                              <th>First Name</th>
                              <th>Last Name</th>
                              <th>Username</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>1</td>
                              <td>Mark</td>
                              <td>Otto</td>
                              <td>@mdo</td>
                            </tr>
                            <tr>
                              <td>2</td>
                              <td>Jacob</td>
                              <td>Thornton</td>
                              <td>@fat</td>
                            </tr>
                            <tr>
                              <td>3</td>
                              <td>Larry</td>
                              <td>the Bird</td>
                              <td>@twitter</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      <div class="panel panel-default">
                        <div class="panel-heading">Panel heading</div>
                        <div class="panel-body">
                          <p>Some default panel content here. Nulla vitae elit libero, a pharetra augue. Aenean lacinia bibendum nulla sed consectetur. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                        </div>
                        <ul class="list-group">
                          <li class="list-group-item">Cras justo odio</li>
                          <li class="list-group-item">Dapibus ac facilisis in</li>
                          <li class="list-group-item">Morbi leo risus</li>
                          <li class="list-group-item">Porta ac consectetur ac</li>
                          <li class="list-group-item">Vestibulum at eros</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

              </div><!-- panel body -->
            </div>