<div class="col-xs-6 col-sm-3 sidebar-offcanvas" role="navigation">
            <ul class="list-group panel">
              <li class="list-group-item"><a href="<?php echo base_url()?>"<i class="glyphicon glyphicon-mobile"></i>WELCOME TO APLIKASI SAP </a></li>     
                
              <?php 
                if ($this->session->userdata('level') == 'admin') {
                 ?>
                <li class="list-group-item"><i class="glyphicon glyphicon-align-justify"></i> <b>MENU UTAMA</b></li>   
                <li class="list-group-item"><i class="glyphicon glyphicon-mobile"></i><b>ADMIN </b></a></li>  
                <li class="list-group-item"><a href="<?php echo base_url()?>"><i class="glyphicon glyphicon-home"></i>Dashboard </a></li>     
                <li>
                  <a href="#demo4" class="list-group-item " data-toggle="collapse"><i class="glyphicon glyphicon-th-large"></i>Data Master  <span class="glyphicon glyphicon-chevron-right"></span></a>
                    <li class="collapse" id="demo4">
                      <a href="barang" class="list-group-item"> Data Barang</a>
                      <a href="customer" class="list-group-item"> Customer</a>
                    </li>

                </li>
                <li>
                  <a href="#demo5" class="list-group-item " data-toggle="collapse"><i class="glyphicon glyphicon-folder-open"></i>Data Transaksi  <span class="glyphicon glyphicon-chevron-right"></span></a>
                    <li class="collapse" id="demo5">
                      <a href="app/penjualan" class="list-group-item">Order</a>
                      <a href="surat" class="list-group-item">Surat Jalan</a>  
                      <a href="kwitansi" class="list-group-item">Kwitansi</a>
                    </li>
                </li>
                <li class="list-group-item"><a href="users"><i class="glyphicon glyphicon-user"></i>Data User </a></li>
                <li class="list-group-item"><a href="<?php echo base_url()?>monitoring"><i class="glyphicon glyphicon-book"></i>Monitoring </a></li>
                <li class="list-group-item"><a href="<?php echo base_url()?>app/logout"><i class="glyphicon glyphicon-share"></i>Logout </a></li>
                <?php 
                } elseif ($this->session->userdata('level') == 'petugas') {
                 ?>
                  <li class="list-group-item"><i class="glyphicon glyphicon-align-justify"></i> <b>MENU UTAMA</b></li>     
                <li class="list-group-item"><i class="glyphicon glyphicon-mobile"></i><b>PETUGAS </b></a></li>
                <li class="list-group-item"><a href="<?php echo base_url()?>"><i class="glyphicon glyphicon-home"></i>Dashboard </a></li>
                <li>
                  <a href="#demo5" class="list-group-item " data-toggle="collapse"><i class="glyphicon glyphicon-folder-open"></i>Data Transaksi  <span class="glyphicon glyphicon-chevron-right"></span></a>
                    <li class="collapse" id="demo5">
                      <a href="app/penjualan" class="list-group-item">Order</a>
                      <a href="surat" class="list-group-item">Surat</a>
                       <a href="kwitansi" class="list-group-item">Kwitansi</a>
                    </li>
                </li>
                <li class="list-group-item"><a href="<?php echo base_url()?>app/logout"><i class="glyphicon glyphicon-share"></i>Logout </a></li>
                

                <?php 
                } elseif ($this->session->userdata('level') == 'manager') {
                ?>
                 <li class="list-group-item"><i class="glyphicon glyphicon-align-justify"></i> <b>MENU UTAMA</b></li>     
                <li class="list-group-item"><i class="glyphicon glyphicon-mobile"></i><b>MANAGER </b></a></li>
                <li class="list-group-item"><a href="<?php echo base_url()?>"><i class="glyphicon glyphicon-home"></i>Dashboard </a></li>
                <li>
                <li class="list-group-item"><a href="<?php echo base_url()?>monitoring"><i class="glyphicon glyphicon-book"></i>Monitoring </a></li>
                </li>
                <li class="list-group-item"><a href="<?php echo base_url()?>app/logout"><i class="glyphicon glyphicon-share"></i>Logout </a></li>

                <?php } ?>
              </ul>
          </div>