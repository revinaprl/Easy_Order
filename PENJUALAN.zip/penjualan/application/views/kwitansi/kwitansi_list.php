
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <form action="Kwitansi/create_action" method="POST">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Tambah Kwitansi</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
            <label>Kode Order</label><br>
          <select id="kode_order" name="kode_order"  class="form-control" required>
            <option value="">--Pilih Kode Order--</option>
            <?php 
            $sql = $this->db->query("SELECT * FROM transaksi WHERE status_order='Selesai'");
            foreach ($sql->result() as $row) {
             ?>
            <option value="<?php echo $row->kode_order; ?>"><?php echo $row->kode_order ?></option>
            <?php } ?>
          </select>
        </div>
       <div class="form-group">
                <label >Kode Kwitansi</label>
                <input type="text" class="form-control" name="kode_kwitansi" id="kode_kwitansi" readonly/>
        </div>
        <div class="form-group">
                <label >Nama Penerima</label>
                <input type="text" class="form-control" name="nama_penerima" id="nama_penerima" required/>
        </div>
        <div class="form-group">
                <label >jumlah Uang</label>
                <input type="text" class="form-control" name="total_bayar" id="total_bayar" readonly />
        </div>
        <div class="form-group">
                <label >Banyak Uang</label>
                <input type="text" class="form-control" name="banyak_uang" id="banyak_uang" required/>
        </div>
        
      
        
      </div>
      <div class="modal-footer">
        <input type="submit" class="btn btn-info" name="submit" value="Simpan">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
    </form>

  </div>
</div>  

<script type="text/javascript">
  $(document).ready(function(){
    $('#kode_order').change(function() {
      var id = $(this).val();
      $.ajax({
        type : 'POST',
        url : '<?php echo base_url('Kwitansi/cek_kwitansi') ?>',
        Cache : false,
        dataType: "json",
        data : 'kode_order='+id,
        success : function(resp) {
             //$('.nama').val(resp.nama);
          
            $('#kode_kwitansi').val(resp.kode_kwitansi);
            
            $('#total_bayar').val(resp.total_bayar);
           
        }
      });
      alert(id);
    });


    
  });
</script>

<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">Tambah Kwitansi</button>
<br>
<br>
        <table class="table table-bordered" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
        <th>Kode Kwitansi</th>
        <th>Kode Order</th>
        <th>Nama Penerima</th>
        <th>Banyak Uang</th>
        <th>Jumlah Uang</th>
        <th>Status Cetak</th>
        <th>Pilihan</th>
            </tr><?php
            foreach ($kwitansi_data as $kwitansi)
            {
                ?>
                <tr>
            <td width="80px"><?php echo ++$start ?></td>
            <td><?php echo $kwitansi->kode_kwitansi ?></td>
            <td><?php echo $kwitansi->kode_order ?></td>
             <td><?php echo $kwitansi->nama_penerima ?></td>
            <td><?php echo $kwitansi->banyak_uang ?></td>
            <td><?php echo $kwitansi->total_bayar ?></td>
            <td><?php echo $kwitansi->status_cetak ?></td>
            
            <td style="text-align:center" width="300px">
                <?php
                echo anchor(base_url('kwitansi/detail_kwitansi?kode_kwitansi='.$kwitansi->kode_kwitansi),'<button class="btn btn-danger"> detail</button>');
                echo ' | '; 
                echo anchor(base_url('kwitansi/cetak_kwitansi?kode_kwitansi='.$kwitansi->kode_kwitansi),'<button class="btn btn-warning" >cetak</button>');
                }
                ?>
            </td>
        </tr>
                <?php
            ?>
        </table>
        <div class="row">
            <div class="col-md-6">
                <a href="#" class="btn btn-primary">Total Record : <?php echo $total_rows ?></a>
        </div>
            <div class="col-md-6 text-right">
                <?php echo $pagination ?>
            </div>
        </div>