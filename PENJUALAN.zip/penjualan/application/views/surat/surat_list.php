
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <form action="Surat/create_action" method="POST">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Tambah Order</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
            <label>Kode Order</label><br>
          <select id="kode_order" name="kode_order"  class="form-control" required>
            <option value="">--Pilih Kode Order--</option>
            <?php 
            $sql = $this->db->query("SELECT * FROM transaksi WHERE status_order='Selesai'");
            foreach ($sql->result() as $row) {
             ?>s
            <option value="<?php echo $row->kode_order; ?>"><?php echo $row->kode_order ?></option>
            <?php } ?>
          </select>
        </div>
       <div class="form-group">
                <label >Kode Surat</label>
                <input type="text" class="form-control" name="kode_surat" id="kode_surat" readonly/>
        </div>
        <div class="form-group">
                <label >Qty Kirim</label>
                <input type="text" class="form-control" name="qty_kirim" id="qty_kirim" required/>
        </div>
        <div class="form-group">
                <label >No Kendaraan</label>
                <input type="text" class="form-control" name="no_kendaraan" id="no_kendaraan" required/>
        </div>
        <div class="form-group">
                <label >Tanggal Kirim</label>
                <input class="form-control" type="date" id="tgl_kirim" name="tgl_kirim" value="<?php echo date("d-m-Y") ?>" required>
        </div>
        <div class="form-group">
                <input class="form-control" type="hidden" id="dikirim" name="dikirim" value="Dikirim" >
        </div>
      </div>
      <div class="modal-footer">
        <input type="hidden" class="form-control" name="nabar" id="nabar"/>
        <input type="submit" class="btn btn-info" name="submit" value="Simpan">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
    </form>

  </div>
</div>  

<script type="text/javascript">
  $(document).ready(function(){
    $('#kode_order').change(function() {
      var id = $(this).val();
      $.ajax({
        type : 'POST',
        url : '<?php echo base_url('Surat/cek_surat') ?>',
        Cache : false,
        dataType: "json",
        data : 'kode_order='+id,
        success : function(resp) {
             //$('.nama').val(resp.nama);
            $('#kode_barang').val(resp.kode_barang);
            $('#kode_surat').val(resp.kode_surat);
            $('#no_kendaraan').val(resp.kode_kendaraan);
            $('#tgl_kirim').val(resp.tgl_kirim);
            $('#qty_kirim').val(resp.qty_kirim);
            $('#dikirim').val(resp.dikirim);
        }
      });
      alert(id);
    });


    
  });
</script>

<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">Tambah Surat</button>
<br>
<br>
        <table class="table table-bordered" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
        <th>Kode Order</th>
        <th>Kode Surat</th>
        <th>No Kendaraan</th>
        <th>Tanggal Kirim</th>
        <th>Status Cetak</th>
        <th>Pilihan</th>
            </tr><?php
            foreach ($surat_data as $surat)
            {
                ?>
                <tr>
            <td width="80px"><?php echo ++$start ?></td>
            <td><?php echo $surat->kode_order ?></td>
            <td><?php echo $surat->kode_surat ?></td>
            <td><?php echo $surat->no_kendaraan ?></td>
            <td><?php echo $surat->tgl_kirim ?></td>
            <td><?php echo $surat->status_cetak ?></td>
            
            <td style="text-align:center" width="200px">
                <?php
                echo anchor(base_url('Surat/detail_surat?kode_order='.$surat->kode_order),'<button class="btn btn-danger" > detail</button>');
                echo ' | '; 
                echo anchor(base_url('surat/cetak_surat?kode_order='.$surat->kode_order),'<button class="btn btn-warning" >cetak</button>');

                    }
                ?>
            </td>
        </tr>
                <?php
            ?>
        </table>
        <div class="row">
            <div class="col-md-6">
                <a href="#" class="btn btn-primary">Total Record : <?php echo $total_rows ?></a>
        </div>
            <div class="col-md-6 text-right">
                <?php echo $pagination ?>
            </div>
        </div>