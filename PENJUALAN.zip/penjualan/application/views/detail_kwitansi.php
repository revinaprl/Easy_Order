<?php 
$kwitansi = $data->row();
$no = 1;
 ?>
<div class="row">
	<div class="col-md-12">
		<table class="table table-bordered" style="margin-bottom: 10px" >
			<thead>
				<tr>
					<th>No.</th>
					<th>Kode Kwitansi</th>
        		<th>Kode Order</th>
       		    <th>Nama Penerima</th>
        		<th>Banyak Uang</th>
        		<th>Jumlah Uang</th>
				</tr>
			</thead>
			<tbody>

				<tr>
					<td><?php echo $no++; ?></td>
					<td><?php echo $kwitansi->kode_kwitansi;?></td>
            		<td><?php echo $kwitansi->kode_order; ?></td>
             		<td><?php echo $kwitansi->nama_penerima; ?></td>
            		<td><?php echo $kwitansi->banyak_uang; ?></td>
            		<td><?php echo $kwitansi->total_bayar; ?></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>