<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <form method="post" enctype="multipart/form-data" action="<?php echo base_url(); ?>monitoring/create_action">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Tambah Monitoring</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
            <label>Kode Order</label><br>
          <select id="kode_order" name="kode_order"  class="form-control" required>
            <option value="">--Pilih Kode Order--</option>
            <?php 
            $sql = $this->db->query("SELECT * FROM transaksi WHERE status_order='proses'");
            foreach ($sql->result() as $row) {
             ?>
            <option value="<?php echo $row->kode_order; ?>"><?php echo $row->kode_order ?></option>
            <?php } ?>
          </select>
        </div>
       <div class="form-group">
            <label>Kode Surat</label><br>
          <select id="kode_surat" name="kode_surat"  class="form-control" required>
            <option value="">--Pilih Kode Surat--</option>
            <?php 
            $sql = $this->db->query("SELECT * FROM transaksi WHERE status_order='proses'");
            foreach ($sql->result() as $row) {
             ?>
            <option value="<?php echo $row->kode_surat; ?>"><?php echo $row->kode_surat ?></option>
            <?php } ?>
          </select>
        </div>
        <div class="form-group">
        <label class="form-control-label" for="input_lunas">Bukti Pembayaran</label>
        <input type="file" name="berkas" id="berkas" required>
        </div>
         <div class="form-group">
                <input class="form-control" type="hidden" id="status" name="status" value="Proses" >
        </div>
        
      
        
      </div>
      <div class="modal-footer">
        <input type="submit" class="btn btn-info" name="submit" value="Simpan">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
    </form>

  </div>
</div> 





<script type="text/javascript">
  $(document).ready(function(){
    $('#kode_order').change(function() {
      var id = $(this).val();
      $.ajax({
        type : 'POST',
        url : '<?php echo base_url('Monitoring/cek_monitoring') ?>',
        Cache : false,
        dataType: "json",
        data : 'kode_order='+id,
        success : function(resp) {
             //$('.nama').val(resp.nama);
            $('#kode_order').val(resp.kode_order);
            $('#kode_surat').val(resp.kode_surat);
          
        }
      });
      alert(id);
    });


    
  });
</script>

<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">Tambah Monitoring</button>
<br>
<br>

<div class="row" style="margin-bottom: 10px">  
        <table class="table table-bordered" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
        <th>Kode Order</th>
        <th>Kode Surat</th>
        <th>Bukti Pembayaran</th>
        <th>Status</th>
        <th>Pilihan</th>
            </tr><?php
            foreach ($monitoring_data as $monitoring)
            {
                ?>
                <tr>
            <td width="80px"><?php echo ++$start ?></td>
            <td><?php echo $monitoring->kode_order ?></td>
            <td><?php echo $monitoring->kode_surat ?></td>
            <td><a href="<?php echo base_url('uploads/' . $monitoring->berkas) ?>" download><?php echo $monitoring->berkas ?></a></td>
            <td><?php echo $monitoring->status;   ?></td>
            
       
         <td style="text-align:center" width="200px">
          
            <?php 
            /*print_r($row->id_monitoring);die;*/

                if ($monitoring->status == 'Proses') { ?>
                    <a href="<?php echo base_url('monitoring/selesai/' . $monitoring->kode_order); ?>" class="btn btn-group btn-danger" onclick="return confirm('Status Order Sudah Tuntas?')"> <i class="fa fa-times"></i></button>

                <?php } else { ?>

                    <!-- <a href="monitoring/selesai/<?php echo $monitoring->id_monitoring; ?>" class="btn btn-warning btn-sm">X</a> -->
                    <a href="<?php echo base_url('monitoring/proses/' . $monitoring->kode_order); ?>" class="btn btn-group btn-success" onclick="return confirm('Status Order Belum Tuntas?')"> <i class="fa fa-check"></i></button>

                        <?php } ?>

               <!--  <a href="monitoring/detail_monitoring/<?php echo $row->id_monitoring ?>" class="btn btn-info btn-sm">detail</a> -->
                
            </td>
        </tr>
                <?php
            }
            ?>
        </table>
        <div class="row">
            <div class="col-md-6">
                <a href="#" class="btn btn-primary">Total Record : <?php echo $total_rows ?></a>
        </div>
            <div class="col-md-6 text-right">
                <?php echo $pagination ?>
            </div>
        </div>