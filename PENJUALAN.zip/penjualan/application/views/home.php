


<div class="jumbotron jumbotron-fluid">
<div class="container">
    
  <center>  <img src="<?php echo base_url();?>assets/img/kop.png" width="80%">
    </center>
  </div>
</div>
<div class="alert alert-success">
  <strong>Selamat Datang</strong>,  
  <?php echo $this->session->userdata('nama'); ?>.
</div>

<div class="alert alert-warning">
  <h4>CV. SURYA ANUGERAH PLASTIK</h4>
		<p>Kp. Tali baju RT 03/ 02 , Des. Cikao Bandung, Kec. Jatiluhur, Kab. Purwakarta 41152</p>
		<p>Telp. (0821)-612673</p>
</div>

