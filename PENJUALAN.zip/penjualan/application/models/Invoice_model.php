<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Invoice_model extends CI_Model
{

    public $table = 'invoice';
    public $id = 'id_invoice';
    public $order = 'DESC';

    function __construct()
    {
        parent::__construct();
    }

    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }
    
    // get total rows
    function total_rows($q = NULL) {
	$this->db->or_like('id_invoice', $q);
    $this->db->or_like('kode_invoice', $q);
    $this->db->or_like('nama_barang', $q);
    $this->db->or_like('qty_barang', $q);
    $this->db->or_like('satuan', $q);
    $this->db->or_like('harga_satuan', $q);
    $this->db->or_like('total_harga', $q);
	$this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db->order_by($this->id, $this->order);
        $this->db->or_like('id_invoice', $q);
    $this->db->or_like('kode_invoice', $q);
    $this->db->or_like('nama_barang', $q);
    $this->db->or_like('qty_barang', $q);
    $this->db->or_like('satuan', $q);
    $this->db->or_like('harga_satuan', $q);
    $this->db->or_like('total_harga', $q);
	$this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }

    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);
    }

    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }
    
    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }

    // cetak data
    function cetak($id)
    {
        $this->db->where($this->id, $id);
        $this->db->cetak($this->table);
    }

    function get_order(){
        $this->db->select('*');
        $this->db->from('detail_transaksi');
        $this->db->where('status_order', 'Selesai');
        $this->db->order_by('$id_detail_order', 'desc');
        $query = $this->db->get();
        return $query->result();
    }

    
}
