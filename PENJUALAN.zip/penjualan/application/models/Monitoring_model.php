<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Monitoring_model extends CI_Model
{

    public $table = 'monitoring';
    public $id = 'id_monitoring';
    public $order = 'DESC';

    function __construct()
    {
        parent::__construct();
    }

    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }
    
    // get total rows
    function total_rows($q = NULL) {
	$this->db->or_like('id_monitoring', $q);
    $this->db->or_like('kode_order', $q);
    $this->db->or_like('kode_surat', $q);
    $this->db->or_like('status', $q);
	$this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db->order_by($this->id, $this->order);
        $this->db->or_like('id_monitoring', $q);
        $this->db->or_like('kode_order', $q);
    $this->db->or_like('kode_surat', $q);
    $this->db->or_like('status', $q);
    $this->db->or_like('berkas', $q);
    $this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }

    public function edit_status($data)
    {
        /*$id_monitoring = $this->input->post('id_monitorong', true);*/
       /* print_r($id_monitoring); die;*/
        // $this->db->where('id_monitoring', $data['id_monitoring']);
        // $this->db->update('monitoring', $data);
       $datas = array(
            'status' => $data['status'],
        );
        $this->db->where('kode_order', $data['kode_order']);
        $this->db->update('monitoring', $datas);
        return $this->db->affected_rows();
    } 

    public function update_status($id){
        $data = array(
            'status' => 'Selesai'
        );
        $this->db->where('id_monitoring', $id);
        $this->db->update('monitoring', $data);
        return $this->db->affected_rows();
    }

    public function detail_monitoring($id_monitoring)
    {
        $this->db->select('*');
        $this->db->from('monitoring');
        $this->db->where('id_monitoring', $id_monitoring);
        $this->db->order_by('id_monitoring', 'desc');
        $query = $this->db->get();
        return $query->row();
    }

    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);
    }
    
}
