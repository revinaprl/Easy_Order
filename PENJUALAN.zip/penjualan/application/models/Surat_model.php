<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Surat_model extends CI_Model
{

    public $table = 'surat';
    public $id = 'id_surat';
    public $order = 'DESC';

    function __construct()
    {
        parent::__construct();
    }

    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }
    
    // get total rows
    function total_rows($s = NULL) {
    $this->db->or_like('kode_order', $s);
    $this->db->or_like('kode_surat', $q);
    
	
	$this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $s = NULL) {
        $this->db->order_by($this->id, $this->order);
        
      
        $this->db->or_like('kode_order', $s);
        $this->db->or_like('kode_surat', $s);
        $this->db->or_like('no_kendaraan', $s);
        $this->db->or_like('tgl_kirim', $s);
      
	$this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }

    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);
    }

    /*public function edit_status_cetak($data){
        $datas = array(
            'status_cetak' => $data['status'],
        );
        $this->db->where('kode_surat', $data['kode_surat']);
        $this->db->update('surat', $datas);
        return $this->db->affected_rows();
    } */
}
