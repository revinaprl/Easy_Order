<?php
/**
 * 
 */
class upload_pembayaran extends CI_Model
{
	
	public function upload(){
    $config['upload_path'] = './upload_pembayaran/';
    $config['allowed_types'] = 'jpg|png|jpeg|pdf';
    $config['max_size']  = '2048';
    $config['remove_space'] = TRUE;
    // $config['file_name'] =  ('krs_',$_SESSION['email']);
  
    $this->load->library('upload', $config); // Load konfigurasi uploadnya
    if($this->upload->do_upload('khs') && $this->upload->do_upload('krs')){ // Lakukan upload dan Cek jika proses upload berhasil
      // Jika berhasil :
      $return = array('result' => 'success', 'file' => $this->upload->data(), 'error' => '');

      return $return;
    }else{
      // Jika gagal :
      $return = array('result' => 'failed', 'file' => '', 'error' => $this->upload->display_errors());
      return $return;
    }
  }
}
?>