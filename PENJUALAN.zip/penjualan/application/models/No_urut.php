<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class No_urut extends CI_Model
{

    function buat_kode_barang()   {    
      $this->db->select('RIGHT(barang.id_barang,4) as kode', FALSE);
      $this->db->order_by('id_barang','DESC');    
      $this->db->limit(1);     
      $query = $this->db->get('barang');      //cek dulu apakah ada sudah ada kode di tabel.    
      if($query->num_rows() <> 0){       
       //jika kode ternyata sudah ada.      
       $data = $query->row();      
       $kode = intval($data->kode) + 1;     
      }
      else{       
       //jika kode belum ada      
       $kode = 1;     
      }
      $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
      $kodejadi = "BRG".$kodemax;     
      return $kodejadi;  
     }

     function buat_kode_order()   {    
      $this->db->select('RIGHT(transaksi.kode_order,5) as kode', FALSE);
      $this->db->order_by('kode_order','DESC');    
      $this->db->limit(1);     
      $query = $this->db->get('transaksi');      //cek dulu apakah ada sudah ada kode di tabel.    
      if($query->num_rows() <> 0){       
       //jika kode ternyata sudah ada.      
       $data = $query->row();      
       $kode = intval($data->kode) + 1;     
      }
      else{       
       //jika kode belum ada      
       $kode = 1;     
      }
      $kodemax = str_pad($kode, 5, "0", STR_PAD_LEFT);    
      $kodejadi = "OR".$kodemax;     
      return $kodejadi;  
     }

     function buat_kode_customer()   {    
      $this->db->select('RIGHT(customer.id_customer,5) as kode', FALSE);
      $this->db->order_by('id_customer','DESC');    
      $this->db->limit(1);     
      $query = $this->db->get('customer');      //cek dulu apakah ada sudah ada kode di tabel.    
      if($query->num_rows() <> 0){       
       //jika kode ternyata sudah ada.      
       $data = $query->row();      
       $kode = intval($data->kode) + 1;     
      }
      else{       
       //jika kode belum ada      
       $kode = 1;     
      }
      $kodemax = str_pad($kode, 5, "0", STR_PAD_LEFT);    
      $kodejadi = "CS".$kodemax;     
      return $kodejadi;  
     }

     function buat_kode_surat()   {    
      $this->db->select('RIGHT(transaksi.kode_surat,5) as kode', FALSE);
      $this->db->order_by('kode_surat','DESC');    
      $this->db->limit(1);     
      $query = $this->db->get('transaksi');      //cek dulu apakah ada sudah ada kode di tabel.    
      if($query->num_rows() <> 0){       
       //jika kode ternyata sudah ada.      
       $data = $query->row();      
       $kode = intval($data->kode) + 1;     
      }
      else{       
       //jika kode belum ada      
       $kode = 1;     
      }
      $kodemax = str_pad($kode, 5, "0", STR_PAD_LEFT);    
      $kodejadi = "SJ".$kodemax;     
      return $kodejadi;  
     }

    function buat_kode_invoice()   {    
      $this->db->select('RIGHT(invoice.id_invoice,5) as kode', FALSE);
      $this->db->order_by('id_invoice','DESC');    
      $this->db->limit(1);     
      $query = $this->db->get('invoice');      //cek dulu apakah ada sudah ada kode di tabel.    
      if($query->num_rows() <> 0){       
       //jika kode ternyata sudah ada.      
       $data = $query->row();      
       $kode = intval($data->kode) + 1;     
      }
      else{       
       //jika kode belum ada      
       $kode = 1;     
      }
      $kodemax = str_pad($kode, 5, "0", STR_PAD_LEFT);    
      $kodejadi = "INV".$kodemax;     
      return $kodejadi;  
     }

     function buat_kode_kwitansi()   {    
      $this->db->select('RIGHT(transaksi.kode_kwitansi,5) as kode', FALSE);
      $this->db->order_by('kode_kwitansi','DESC');    
      $this->db->limit(1);     
      $query = $this->db->get('transaksi');      //cek dulu apakah ada sudah ada kode di tabel.    
      if($query->num_rows() <> 0){       
       //jika kode ternyata sudah ada.      
       $data = $query->row();      
       $kode = intval($data->kode) + 1;     
      }
      else{       
       //jika kode belum ada      
       $kode = 1;     
      }
      $kodemax = str_pad($kode, 5, "0", STR_PAD_LEFT);    
      $kodejadi = "KW".$kodemax;     
      return $kodejadi;  
     }

     function buat_kode_monitoring()   {    
      $this->db->select('RIGHT(monitoring.id_monitoring,5) as kode', FALSE);
      $this->db->order_by('id_monitoring','DESC');    
      $this->db->limit(1);     
      $query = $this->db->get('monitoring');      //cek dulu apakah ada sudah ada kode di tabel.    
      if($query->num_rows() <> 0){       
       //jika kode ternyata sudah ada.      
       $data = $query->row();      
       $kode = intval($data->kode) + 1;     
      }
      else{       
       //jika kode belum ada      
       $kode = 1;     
      }
      $kodemax = str_pad($kode, 5, "0", STR_PAD_LEFT);    
      $kodejadi = "MR".$kodemax;     
      return $kodejadi;  
     }

      public function kode_surat(){
        $this->db->select('RIGHT(transaksi.kode_surat,2) as kode_surat', FALSE);
        $this->db->order_by('kode_surat','DESC');    
        $this->db->limit(1);    
        $query = $this->db->get('transaksi');  //cek dulu apakah ada sudah ada kode di tabel.    
        if($query->num_rows() <> 0){      
           //cek kode jika telah tersedia    
           $data = $query->row();      
           $kode = intval($data->kode_surat) + 1; 
        }
        else{      
           $kode = 1;  //cek jika kode belum terdapat pada table
        }
          $batas = str_pad($kode, 3, "0", STR_PAD_LEFT);    
          $kodetampil = "SJ"."5".$batas;  //format kode
          return $kodetampil;  
     }

}
