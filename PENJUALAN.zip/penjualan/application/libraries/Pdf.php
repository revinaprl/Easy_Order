<?php
class Pdf{
function_construct(){
	include_once APPATH . '/thrid_party/fpdf.php';
	}
	}
?>