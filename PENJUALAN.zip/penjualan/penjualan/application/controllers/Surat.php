<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Surat extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Surat_model');
        $this->load->model('No_urut');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('s', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'surat/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'surat/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'surat/index.html';
            $config['first_url'] = base_url() . 'surat/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Surat_model->total_rows($q);
        $surat = $this->Surat_model->get_limit_data($config['per_page'], $start, $q);
        // $surat = $this->Surat_model->show_surat();

        $this->load->library('pagination');
        $this->pagination->initialize($config);


        $data = array(
            'surat_data' => $surat,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
            'konten' => 'surat/surat_list',
            'judul' => 'Data Surat',
        );
        $this->load->view('v_index', $data);
    }

    public function read($id) 
    {
        $row = $this->Surat_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_surat' => $row->id_surat,
		'kode_surat' => $row->kode_surat,
		'nama_barang' => $row->nama_barang,
        'no_kendaraan' => $row->no_kendaraan,
        'tgl_kirim' => $row->tgl_kirim,
        'qty_order' => $row->qty_order,
        'qty_kirim' => $row->qty_kirim,
        'sisa_order' => $row->sisa_order,
	    );
            $this->load->view('surat/surat_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('surat'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('surat/create_action'),
	    'id_surat' => set_value('id_surat'),
	    'kode_surat' => $this->No_urut->buat_kode_surat(),
        'nama_barang' => set_value('nama_barang'),
        'no_kendaraan' => set_value('no_kendaraan'),
        'tgl_kirim' => set_value('tgl_kirim'),
        'qty_order' => set_value('qty_order'),
        'qty_kirim' => set_value('qty_kirim'),
        'sisa_order' => set_value('sisa_order'),
        'konten' => 'surat/surat_form',
            'judul' => 'Data Surat',
	);
        $this->load->view('v_index', $data);
    }

    public function cek_surat()
	{
        $kode_order = $this->input->post('kode_order');
        $cek = $this->db->query("SELECT * FROM transaksi WHERE kode_order='$kode_order'")->row();
		$data = array(
			'id_order' => $cek->id_order,
			'kode_surat' => $cek->kode_surat,
			'nama_customer' => $cek->nama_customer,
			'tgl_order' => $cek->total_harga,
			'status_order' => $cek->status_order,
		);
		echo json_encode($data);
	}
    
    public function create_action() 
    {
        $this->_rules();

        // if ($this->form_validation->run() == FALSE) {
        //     $this->create();
        // } else {

            $data = array(
        'kode_order' => $this->input->post('kode_order'),
        'kode_surat' => $this->input->post('kode_surat'),
        'tgl_kirim' => $this->input->post('tgl_kirim'),
        'no_kendaraan' => $this->input->post('no_kendaraan'),
        'qty_kirim' => $this->input->post('qty_kirim'),
            );

            $this->Surat_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('surat'));
       // }
    }

    public function update($id) 
    {
        $row = $this->Surat_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('surat/update_action'),
        'id_surat' => set_value('id_surat', $row->id_surat),
        'kode_surat' => set_value('kode_surat', $row->kode_surat),
        'nama_barang' => set_value('nama_barang', $row->nama_barang),
        'no_kendaraan' => set_value('no_kendaraan', $row->no_kendaraan),
        'tgl_kirim' => set_value('tgl_kirim', $row->tgl_kirim),
        'qty_order' => set_value('qty_order', $row->qty_order),
        'qty_kirim' => set_value('qty_kirim', $row->qty_kirim),
        'sisa_order' => set_value('sisa_order', $row->sisa_order),
        'konten' => 'surat/surat_form',
            'judul' => 'Data Surat',
        );
            $this->load->view('v_index', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('surat'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_surat', TRUE));
        } else {
            $data = array(
        'kode_surat' => $this->input->post('kode_surat',TRUE),
        'nama_barang' => $this->input->post('nama_barang',TRUE),
        'no_kendaraan' => $this->input->post('no_kendaraan',TRUE),
        'tgl_kirim' => $this->input->post('tgl_kirim',TRUE),
        'qty_order' => $this->input->post('qty_order',TRUE),
        'qty_kirim' => $this->input->post('qty_kirim',TRUE),
        'sisa_order' => $this->input->post('sisa_order',TRUE),
        );

            $this->Surat_model->update($this->input->post('id_surat', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('surat'));
        }
    }

    
     public function delete($id) 
    {
        $row = $this->Surat_model->get_by_id($id);

        if ($row) {
            $this->Surat_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('surat'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('surat'));
        }
    }

    public function cetak_surat()
    {
        $kode_order = $_GET['kode_order'];
        $data = array(
            'data' => $this->db->query("SELECT t.* , c.nama_customer as cust_nama, s.no_kendaraan as kd_kd,s.tgl_kirim as gtl_kirim, c.no_telp as telp_no  FROM transaksi t 
            join customer c on t.nama_customer = c.kode_customer 
            join surat s on s.kode_order = t.kode_order 
            WHERE s.kode_order = '$kode_order'"),
        );
        $this->load->view('cetak_surat',$data);
    }

    public function detail_surat()
    {
        $kode_order = $_GET['kode_order'];
        $data = array(
            'konten' => 'detail_surat',
            'judul' => 'Detail Surat',
            'data' => $this->db->query("SELECT t.* , c.nama_customer as cust_nama, s.no_kendaraan as kd_kd,s.tgl_kirim as gtl_kirim, c.no_telp as telp_no  FROM transaksi t 
            join customer c on t.nama_customer = c.kode_customer 
            join surat s on s.kode_order = t.kode_order 
            WHERE s.kode_order = '$kode_order'"),
        );
        $this->load->view('v_index',$data);
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('kode_surat', 'kode surat', 'trim|required');
    $this->form_validation->set_rules('nama_barang', 'nama barang', 'trim|required');
    $this->form_validation->set_rules('tgl_kirim', 'tgl kirim', 'trim|required');
	$this->form_validation->set_rules('qty_order', 'qty order', 'trim|required');
	$this->form_validation->set_rules('qty_kirim', 'qty kirim', 'trim|required');
    $this->form_validation->set_rules('sisa_order', 'sisa order', 'trim|required');
	$this->form_validation->set_rules('id_surat', 'id_surat', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

