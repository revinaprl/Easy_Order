<?php
	/**
	 * 
	 */
	class Order extends CI_Controller
	{
		public function tambah_order()
		{
			$this->load->model('No_urut');
			$data = array(
				'konten' => 'tambah_order',
				'judul' => 'Tambah Pemesanan',
				'kodeurut' => $this->No_urut->buat_kode_penjualan(),
				'kode_surat' => $this->No_urut->kode_surat(),
			);
			$this->load->view("v_index",$data);
		}

		public function simpan_master()
		{
			$kode_trnsj_psn = $_POST['kode_trnsj_psn'];
			$kode_customer = $_POST['kode_customer'];
			$tgl_order = $_POST['tgl_order'];
			$disc = $_POST['disc'];
			$ppn = $_POST['ppn'];

			//disini cek kode_trnsj_psn
			$cek_kode = $this->db->query("select * from trnsj_psn where kode_trnsj_psn = '$kode_trnsj_psn'")->result();
			if (count($cek_kode) > 0)
			{
				echo "udad";
				exit();
			}

			if ($disc < 0 || $disc > 100)
			{
				echo "errdisc";
				exit();
			}

			if ($ppn < 0 || $ppn > 100)
			{
				echo "errppn";
				exit();
			}

			$this->db->query("INSERT INTO trnsj_psn SET
								kode_trnsj_psn = '$kode_trnsj_psn',
								kode_customer = '$kode_customer',
								tgl_order = '$tgl_order',
								disc = '$disc',
								ppn = '$ppn',
								gttl_hrg = '0',
								pembulatan = '0',
								gttl_hrg2 = '0',
								status = 'proses',
								status_cetak = 'belum'");

			echo "OK";
		}

		public function simpan_dtl()
		{
			$kode_trnsj_psn = $_POST['kode_trnsj_psn'];
			$kode_barang = $_POST['kode_barang'];
			$qty = $_POST['qty'];
			$hrg_jl = $_POST['hrg_jl'];

			if ($qty <= 0)
			{
				echo "errqty";
				exit();
			}

			if ($hrg_jl <= 0)
			{
				echo "errhrg";
				exit();
			}

			$qty = round($qty,2);
			$hrg_jl = round($hrg_jl,2);
			$gttl_hrg = $qty * $hrg_jl;
			$gttl_hrg = round($gttl_hrg,2);

			$disc = 0;
			$ppn = 0;

			//disini ambil master data
			$query = $this->db->query("select * from trnsj_psn where kode_trnsj_psn = '$kode_trnsj_psn'")->result();
			foreach ($query as $data)
			{
				$ppn = $data->ppn;
				$disc = $data->disc;
			}

			//disini insert datanya
			$this->db->query("INSERT INTO trnsj_psn_dtl SET
								kode_trnsj_psn = '$kode_trnsj_psn',
								kode_barang = '$kode_barang',
								qty_barang = '$qty',
								hrg_pk = '0',
								hrg_jl = '$hrg_jl',
								gttl_hrg = '$gttl_hrg'");

			//disini ambil data detail
			$grand_total_dtl = 0;
			$q_dtl = $this->db->query("SELECT * FROM trnsj_psn_dtl WHERE kode_trnsj_psn = '$kode_trnsj_psn'")->result();
			foreach ($q_dtl as $d_dtl)
			{
				$grand_total_dtl += $d_dtl->gttl_hrg;
			}

			//disini hitung ulang masternya
			$disc_rp = $grand_total_dtl*($disc/100);
			$disc_rp = round($disc_rp,2); //ini untuk nilai diskon
			$ppn_rp = ($grand_total_dtl-$disc_rp)*($ppn/100);
			$ppn_rp = round($ppn_rp,2);

			$gttl_hrg = $grand_total_dtl-$disc_rp+$ppn_rp;
			$gttl_hrg = round($gttl_hrg,2);

			//disini ambil grand total 2
			$gttl_hrg2 = 0.01*ceil(100*$gttl_hrg);
			$gttl_hrg2 = round($gttl_hrg2,2);
			$pembulatan = $gttl_hrg-$gttl_hrg2;
			$pembulatan = round($pembulatan,2);


			//disini update transaksi
			$this->db->query("UPDATE trnsj_psn SET
								gttl_hrg = '$gttl_hrg',
								pembulatan = '$pembulatan',
								gttl_hrg2 = '$gttl_hrg2'
								WHERE kode_trnsj_psn = '$kode_trnsj_psn'");

			echo "OK";
		}

		public function simpan_cart($id)
		{
		
        $data = array(
            'kode_trnsj_psn '    => $this->input->post('kode_trnsj_psn '),
            'kode_customer'   => $this->input->post('kode_customer'),
            'kode_barang' => $this->input->post('kode_barang'),
            'nama_customer' => $this->input->post('nama_customer'),
            'nama_barang' => $this->input->post('nama_barang'),
            'qty_order' => $this->input->post('qty_order'),
            'hrg_jl'  => $this->input->post('harga_barang'),
            'gttl_hrg'  => $this->input->post('gttl_hrg'),
        );
        $this->cart->insert($data);
        redirect('app/tambah_order');
		}

		public function hapus_cart($id)
		{
		
        $data = array(
            'rowid'    => $id,
            'qty'   => 0,
        );
        $this->cart->update($data);
        redirect('app/tambah_order');
		}

		public function cetak_kwitansi()
		{
			# code...
		}

		public function cetak_invoice()
		{
			# code...
		}

		public function cetak_order()
		{
			# code...
		}

		public function detail_order()
		{
			# code...
		}
	}
?>