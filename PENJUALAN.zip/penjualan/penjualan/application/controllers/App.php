<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class App extends CI_Controller {
	
	public function index()
	{
		if ($this->session->userdata('level') == "") {
            redirect('app/login');
        } 
		$data = array(
			'konten' => 'home',
            'judul' => 'Dashboard',
            'data1' => 'proses',
            'data1' => 'selesai'
		);
		$this->load->view('v_index', $data);
	}

	public function login()
	{

		if ($this->input->post() == NULL) {
			$this->load->view('login');
		} else {
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$cek_user = $this->db->query("SELECT * FROM users WHERE username='$username' and password='$password' ");
			if ($cek_user->num_rows() == 1) {
				foreach ($cek_user->result() as $row) {
					$sess_data['id_user'] = $row->id_user;
					$sess_data['nama'] = $row->nama_user;
					$sess_data['username'] = $row->username;
					$sess_data['level'] = $row->level;
					$this->session->set_userdata($sess_data);
				}
				redirect('app');
			} else {
				?>
				<script type="text/javascript">
					alert('Username dan password kamu salah !');
					window.location="<?php echo base_url('app/login'); ?>";
				</script>
				<?php
			}
		}
	}

	function logout()
	{
		$this->session->unset_userdata('id_user');
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('nama');
		$this->session->unset_userdata('level');
		session_destroy();
		redirect('app/login');
	}

	public function cek_barang()
	{
        $kode_barang = $this->input->post('kode_barang');
        $cek = $this->db->query("SELECT * FROM barang WHERE kode_barang='$kode_barang'")->row();
		$data = array(
			'id_barang' => $cek->id_barang,
			'kategori' => $cek->kategori,
			'stok' => $cek->stok,
			'harga' => $cek->harga,
			'kode_barang' => $cek->kode_barang,
			'nama_barang' => $cek->nama_barang,
		);
		echo json_encode($data);
	}

	

	private function _validasi()
    {
        $this->form_validation->set_rules('id_barang', 'Barang', 'required');

        $input = $this->input->post('id_barang', true);
        $stok = $this->admin->get('barang', ['id_barang' => $input])['stok'];
        $stok_valid = $stok + 1;

        $this->form_validation->set_rules(
            'qty',
            'Qty Order',
            "required|trim|numeric|greater_than[0]|less_than[{$stok_valid}]",
            [
                'less_than' => "Qty Order tidak boleh lebih dari {$stok}"
            ]
        );
    }

	public function tambah_penjualan()
	{
		$this->load->model('No_urut');

		$data = array(
			'konten' => 'form_penjualan',
			'judul' => 'Tambah Order',
			'kodeurut' => $this->No_urut->buat_kode_order(),
			'kode_surat' => $this->No_urut->buat_kode_surat(),
		);
		$this->load->view('v_index',$data);
	}

	public function hapus_penjualan($kode_order)
	{
		
        $this->db->where('kode_order', $kode_order);
		$this->db->delete('transaksi');
		$this->db->where('kode_order', $kode_order);
		$this->db->delete('detail_transaksi');
		?>
		<script type="text/javascript">
			alert('Berhasil Hapus Data');
			window.location='<?php echo base_url('app/penjualan') ?>';
		</script>
		<?php
	}

	public function detail_penjualan($kode_order)
	{
		$data = array(
			'konten' => 'detail_penjualan',
			'judul' => 'Detail Order',
			'data' => $this->db->query("SELECT * FROM transaksi where kode_order='$kode_order'"),
		);
		$this->load->view('v_index',$data);
	}


	public function simpan_penjualan()
	{
		$kode_order = $this->input->post('kode_order');
		$kode_surat = $this->input->post('kode_surat');
		$nama_customer = $this->input->post('nama_customer');
		
        $barang = $this->Order_model->detail_barang($kode_order);

        foreach ($this->cart->contents() as $items) {
        	$kode_barang = $items['id'];
        	$qty = $items['qty'];
       		$satuan = $items['satuan'];
			$d = array(	
	    		'kode_order' => $kode_order,
	    		'kode_barang' => $kode_barang,
	    		'qty' => $qty,
	    		'satuan' => $satuan,
	    	);
	    	$this->db->insert('detail_transaksi', $d);
        	
        }

        $tgl_penjualan = $this->input->post('tgl_transaksi');
        $total_harga = $this->input->post('total_harga');
        $data = array(
			'kode_order'=> $kode_order,
			'kode_surat'=> $kode_surat,
            'nama_customer'=> $nama_customer,
            'total_harga'=> $total_harga,
            'tgl_order'=> $tgl_penjualan,
        	'status_order' => 'Proses'

        );
        $this->db->insert('transaksi', $data);
        $this->cart->destroy();
        redirect('app/penjualan');
	}

	public function cetak_penjualan()
	{
		
        $data = array(
			'data' => $this->db->query("SELECT * FROM transaksi where kode_order='$kode_order'"),
		);
		$this->load->view('cetak_penjualan',$data);
	}


	public function simpan_cart()
    {

        $data = array(
            'id'    => $this->input->post('kode_barang'),
            'category' => $this->input->post('kategori'),
            'name'  => $this->input->post('nabar'),
            'qty'   => $this->input->post('stok'),
            'satuan' => $this->input->post('satuan'),
            'price' => $this->input->post('harga'),

        );
        $this->cart->insert($data);
        redirect('app/tambah_penjualan');
    }

	public function hapus_cart($id)
	{
		
        $data = array(
            'rowid'    => $id,
            'qty'   => 0,
        );
        $this->cart->update($data);
        redirect('app/tambah_penjualan');
	}
	

	public function penjualan()
	{
		$data = array(
			'konten' => 'penjualan',
			'judul' => 'Data Order',
		);
		$this->load->view('v_index',$data);
	}



 public function edit_status($id_order)
    {
        $transaksi = $this->Order_model->detail_order($id_order);
        //validasi input
    
        $i = $this->input;
        
        $data = array(
            'id_user'   => $id_user,
            'status' => $i->post('status')
        );
        $this->Order_model->edit_status($data);
        $this->session->set_flashdata('sukses', 'STATUS TELAH DIEDIT');
        redirect(base_url('app/penjualan'), 'refresh');
    }

    public function proses($id_order)
    {
        $order = $this->Order_model->detail_order($id_order);
        $i = $this->input;
        $data = array(
            'id_order' => $id_order,
            'status_order' => 'Selesai'
        );
        $this->Order_model->edit_status($data);
        $this->session->set_flashdata('sukses', 'USER BERHASIL DI NON-AKTIFKAN');
        redirect(base_url('app/penjualan'), 'refresh');
    }
    public function selesai($id_order)
    {
    	$order = $this->Order_model->detail_order($id_order);
        $i = $this->input;
        $data = array(
            'id_order' => $id_order,
            'status_order' => 'Proses'
        );
        $this->Order_model->edit_status($data);
        $this->session->set_flashdata('sukses', 'USER BERHASIL DI AKTIFKAN');
        redirect(base_url('app/penjualan'), 'refresh');
    }
}
