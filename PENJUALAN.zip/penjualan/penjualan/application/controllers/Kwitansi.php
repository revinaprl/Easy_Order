<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Kwitansi extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Kwitansi_model');
		$this->load->model('No_urut');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'kwitansi/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'kwitansi/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'kwitansi/index.html';
            $config['first_url'] = base_url() . 'kwitansi/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Kwitansi_model->total_rows($q);
        $kwitansi = $this->Kwitansi_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'kwitansi_data' => $kwitansi,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
            'konten' => 'kwitansi/kwitansi_list',
            'judul' => 'Data Kwitansi',
        );
        $this->load->view('v_index', $data);
    }

    public function read($id) 
    {
        $row = $this->Kwitansi_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_kwitansi' => $row->id_kwitansi,
        'kode_kwitansi' => $row->kode_kwitansi,
        'kode_order' => $row->kode_order,
		'nama_penerima' => $row->nama_penerima,
        'banyak_uang' => $row->banyak_uang,
        'jumlah_uang' => $row->jumlah_uang,
	    );
            $this->load->view('kwitansi/kwitansi_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('kwitansi'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('kwitansi/create_action'),
	    'id_kwitansi' => set_value('id_kwitansi'),
        'kode_kwitansi' => $this->No_urut->buat_kode_kwitansi(),
        'kode_order' => set_value('kode_order'),
        'nama_penerima' => set_value('nama_penerima'),
        'banyak_uang' => set_value('banyak_uang'),
        'jumlah_uang' => set_value('jumlah_uang'),
        'konten' => 'kwitansi/kwitansi_form',
            'judul' => 'Data Kwitansi',
	);
        $this->load->view('v_index', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
        'kode_kwitansi' => $this->input->post('kode_kwitansi',TRUE),
		'kode_order' => $this->input->post('kode_order',TRUE),
        'nama_penerima' => $this->input->post('nama_penerima',TRUE),
        'banyak_uang' => $this->input->post('banyak_uang',TRUE),
        'jumlah_uang' => $this->input->post('jumlah_uang',TRUE),
	    );

            $this->Kwitansi_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('kwitansi'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Kwitansi_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('kwitansi/update_action'),
        'id_kwitansi' => set_value('id_kwitansi', $row->id_kwitansi),
        'kode_kwitansi' => set_value('kode_kwitansi', $row->kode_kwitansi),
        'kode_invoice' => set_value('kode_invoice', $row->kode_invoice),
        'nama_penerima' => set_value('nama_penerima', $row->nama_penerima),
        'banyak_uang' => set_value('banyak_uang', $row->banyak_uang),
        'jumlah_uang' => set_value('jumlah_uang', $row->jumlah_uang),
        'konten' => 'kwitansi/kwitansi_formt',
            'judul' => 'Data Kwitansi',
        );
            $this->load->view('v_index', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('kwitansi'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_kwitansi', TRUE));
        } else {
            $data = array(
        'kode_kwitansi' => $this->input->post('kode_kwitansi',TRUE),
        'kode_invoice' => $this->input->post('kode_invoice',TRUE),
        'nama_penerima' => $this->input->post('nama_penerima',TRUE),
        'banyak_uang' => $this->input->post('banyak_uang',TRUE),
        'jumlah_uang' => $this->input->post('jumlah_uang',TRUE),
        );

            $this->Kwitansi_model->update($this->input->post('id_kwitansi', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('kwitansi'));
        }
    }

    public function delete($id) 
    {
        $row = $this->Kwitansi_model->get_by_id($id);

        if ($row) {
            $this->Kwitansi_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('kwitansi'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('kwitansi'));
        }
    }

    public function cetak_kwitansi()
    {
        $kode_kwitansi = $_GET['kode_kwitansi'];

        $data['data'] = $this->db->query("SELECT *FROM kwitansi WHERE kode_kwitansi='$kode_kwitansi'")->result();
        $this->load->view('cetak_kwitansi',$data);
    }

    public function detail_kwitansi()
    {
        $kode_kwitansi = $_GET['kode_kwitansi'];
        $data = array(
            'konten' => 'detail_kwitansi',
            'judul' => 'Detail Kwitansi',
            'data' => $this->db->query("SELECT *FROM kwitansi WHERE kode_kwitansi='$kode_kwitansi'"),
        );
        $this->load->view('v_index',$data);
    }

    public function _rules() 
    {
    $this->form_validation->set_rules('kode_kwitansi', 'kode kwitansi', 'trim|required');
	$this->form_validation->set_rules('kode_order', 'kode_order invoice', 'trim|required');
    $this->form_validation->set_rules('nama_penerima', 'nama penerima', 'trim|required');
	$this->form_validation->set_rules('banyak_uang', 'banyak uang', 'trim|required');
    $this->form_validation->set_rules('jumlah_uang', 'jumlah uang', 'trim|required');
    $this->form_validation->set_rules('id_kwitansi', 'id_kwitansi', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}
