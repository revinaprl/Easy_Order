<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Monitoring extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Monitoring_model');
        $this->load->model('No_urut');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('s', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'monitoring/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'monitoring/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'monitoring/index.html';
            $config['first_url'] = base_url() . 'monitoring/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Monitoring_model->total_rows($q);
        $monitoring = $this->Monitoring_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'monitoring_data' => $monitoring,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
            'konten' => 'monitoring/monitoring_list',
            'judul' => 'Data Monitoring',
        );
        $this->load->view('v_index', $data);
    }

    public function read($id) 
    {
        $row = $this->Monitoring_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_monitoring' => $row->id_monitoring,
        'kode_monitoring' => $row->kode_monitoring,
		'kode_order' => $row->kode_order,
		'kode_customer' => $row->nama_barang,
        'kode_barang' => $row->no_kendaraan,
        'tgl_order' => $row->tgl_order,
        'tgl_kirim' => $row->tgl_kirim,
        'qty_order' => $row->qty_order,
        'qty_kirim' => $row->qty_kirim,
        'status' => $row->status,
	    );
            $this->load->view('monitoring/monitoring_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('monitoring'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('monitoring/create_action'),
	    'id_monitoring' => set_value('id_monitoring'),
	    'kode_order' => set_value('kode_order'),
        'kode_surat' => set_value('kode_surat'),
        'status' => set_value('status'),
        'konten' => 'monitoring/monitoring_form',
            'judul' => 'Data Monitoring',
	);
        $this->load->view('v_index', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {

            $data = array(

		'kode_order' => $this->input->post('kode_order',TRUE),
        'kode_surat' => $this->input->post('kode_surat',TRUE),
        'status' => $this->input->post('status',TRUE),
	    );

            $this->Monitoring_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('monitoring'));
        }
    }

    

    public function detail_monitoring()
    {
        $kode_monitoring = $_GET['kode_monitoring'];
        $data = array(
            'konten' => 'detail_monitoring',
            'judul' => 'Detail Monitoring',
            'data' => $this->db->query("SELECT * FROM monitoring where kode_monitoring='$kode_monitoring'"),
        );
        $this->load->view('v_index',$data);
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('kode_order', 'kode order', 'trim|required');
    $this->form_validation->set_rules('kode_surat', 'kode_surat', 'trim|required');
    $this->form_validation->set_rules('status', 'status', 'trim|required');
	$this->form_validation->set_rules('id_monitoring', 'id_monitoring', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

