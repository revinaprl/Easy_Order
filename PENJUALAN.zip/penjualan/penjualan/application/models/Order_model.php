<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Order_model extends CI_Model
{

public function detail_order($id_order)
    {
        $this->db->select('*');
        $this->db->from('transaksi');
        $this->db->where('id_order', $id_order);
        $this->db->order_by('id_order', 'desc');
        $query = $this->db->get();
        return $query->row();
    }
    public function edit_status($data)
    {
        $this->db->where('id_order', $data['id_order']);
        $this->db->update('transaksi', $data);
    }

    public function detail_barang($id_barang){
        $this->db->select('*');
        $this->db->from('barang');
        $this->db->where('id_barang', $id_barang);
        $query = $this->db->get();
        return $query->row();
    }

    

}
