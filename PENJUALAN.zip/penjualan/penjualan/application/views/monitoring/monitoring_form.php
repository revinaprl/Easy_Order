<form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data">
        
        <div class="form-group">
            <label for="int">Kode Order <?php echo form_error('kode_order') ?></label>
            <input type="text" class="form-control" name="kode_order" id="kode_order" placeholder="Kode Order" value="<?php echo $kode_order; ?>" />
        </div>
        <div class="form-group">
            <label for="int">Kode Surat <?php echo form_error('kode_customer') ?></label>
            <input type="text" class="form-control" name="kode_surat" id="kode_surat" placeholder="Kode Surat" value="<?php echo $kode_surat; ?>" />
        </div>
        <div class="form-group">
            <label for="varchar">Status <?php echo form_error('status') ?></label>
            <input type="text" class="form-control" name="status" id="status" placeholder="Status" value="<?php echo $status; ?>" />
        </div>
        <input type="hidden" name="id_monitoring" value="<?php echo $id_monitoring; ?>" /> 
        <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
        <a href="<?php echo site_url('surat') ?>" class="btn btn-default">Cancel</a>
    </form>