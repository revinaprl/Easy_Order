<div class="row" style="margin-bottom: 10px">
            <div class="col-md-4">
                <?php 
                if ($this->session->userdata('level') == 'admin') {
                 
                echo anchor(site_url('monitoring/create'),'Create', 'class="btn btn-primary"'); 
                }elseif ($this->session->userdata('level') == 'manager') {
                    echo '';
                }
                ?>
            </div>

           
        <table class="table table-bordered" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
        <th>Kode Order</th>
        <th>Kode Surat</th>
        <th>Status</th>
            </tr><?php
            foreach ($monitoring_data as $monitoring)
            {
                ?>
                <tr>
            <td width="80px"><?php echo ++$start ?></td>
            <td><?php echo $monitoring->kode_order ?></td>
            <td><?php echo $monitoring->kode_surat ?></td>
            <td><?php echo $monitoring->status ?></td>
           
        </tr>
                <?php
            }
            ?>
        </table>
        <div class="row">
            <div class="col-md-6">
                <a href="#" class="btn btn-primary">Total Record : <?php echo $total_rows ?></a>
        </div>
            <div class="col-md-6 text-right">
                <?php echo $pagination ?>
            </div>
        </div>