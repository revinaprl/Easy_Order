<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Monitoring Read</h2>
        <table class="table">
        <tr><td>Kode Monitoring</td><td><?php echo $kode_monitoring; ?></td></tr>
	    <tr><td>Kode Order</td><td><?php echo $kode_order; ?></td></tr>
        <tr><td>Kode Customer</td><td><?php echo $kode_customer; ?></td></tr>
        <tr><td>Kode Barang</td><td><?php echo $kode_barang; ?></td></tr>
         <tr><td>Tanggal Order</td><td><?php echo $tgl_order; ?></td></tr>
        <tr><td>Tanggal Kirim</td><td><?php echo $tgl_kirim; ?></td></tr>
	    <tr><td>Qty Order</td><td><?php echo $qty_order; ?></td></tr>
        <tr><td>Qty Kirim</td><td><?php echo $qty_kirim; ?></td></tr>
        <tr><td>Status</td><td><?php echo $status; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('monitoring') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>