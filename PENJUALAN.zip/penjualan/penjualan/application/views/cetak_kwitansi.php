<!DOCTYPE html>

<html>
<head>
	<base href="<?php echo base_url() ?>">
	<title>Cetak Kwitansi</title>
	<link rel="stylesheet" type="text/css" href="assets/bootflat-admin/css/bootstrap.min.css">
</head>
<body onload="window.print();">
	<div class="container">
	<center>
		<table>
			<tr>
				<td width="70px" rowspan="3"><img src="<?php echo base_url('logo/sap.png') ?>" width='50px'></td>
				<td style="text-align: center;"><h4>CV. SURYA ANUGERAH PLASTIK</h4></td>

			</tr>
			<tr>
				
				<td style="text-align: center;"><p>Jl. Cilalawak, Purwakarta</p></td>
			</tr>
			<tr>
				
				<td style="text-align: center;"><p>Telp. (0821)-612673</p></td>
			</tr>
			
		</table>
		<p style="text-align: right;"><b>KWITANSI</b></p>
	</center>
	<hr style=" height: 2px; color:red;background-color:black">
	<div class="row">
		<div class="col-md-12">
			<table class="table">
				<?php
					foreach ($data as $data_cetak)
					{
						?>
						<tr>
							<th style="width: 120px">Kode Kwitansi</th>
							<th style="width: 20px"> : </th>
							<td><?php echo $data_cetak->kode_kwitansi; ?></td>
							
						</tr>
						<tr>
							<th style="width: 150px">Serah Terima Dari</th>
							<th style="width: 20px">:</th>
							<td><?php echo $data_cetak->nama_penerima; ?></td> 
						</tr>
						<tr>
							<th style="width: 150px">Banyaknya uang</th>
							<th style="width: 20px">:</th>
							<td><?php echo $data_cetak->banyak_uang; ?></td> 
						</tr>
				
						<?php
					}
				?>
			</table>
			<table class="table">
						<tr>
							<th style="width: 150px">Struk Pembayaran</th>
							<th style="width: 20px">:</th>
							<td style="width: 150px">Order Nomor</td> 
							<td style="width: 20px">:</td>
							<td><?php echo $data_cetak->kode_order; ?></td>
						</tr>
						<tr>
							<th style="width: 150px"></th>
							<th style="width: 20px"></th>
							<td style="width: 150px">Bayar</td> 
							<td style="width: 20px">:</td>
							<td style="width: 200px">Rp. <?php echo $data_cetak->jumlah_uang; ?></td>
							<td style="width: 20px">PPN (10%)</td>
							<td>:</td>
							<?php
								$bayar = $data_cetak->jumlah_uang;
								$PPN = $bayar*10/100;
							?>
							<td>Rp. <?php echo $PPN; ?></td>
						</tr>
						</table>
				</div>
						<!--
						<div style="text-align: right;">
							<table>
								<tr>
									<td><p>Purwakarta, <?php echo date('d/m/Y') ?></p>
				<br><br><br><br><br>
				<p>Nurhayati</p></td>
								</tr>
							</table>
						</div>
					-->
						<div class="row">
							<div class="col-md-6">
								<table border="3" style="border-right: none; border-left: none;">
								<?php
									$total_bayar = $bayar+$PPN;
								?><tr>
								<th style="padding: 10px;"><span> Total Pembayaran: Rp. <?php echo $total_bayar; ?>,-</span></th>
								</tr>
								</table>
							</div>
							<div class="col-md-6 text-right">
								<p>Purwakarta, <?php echo date('d/m/Y') ?></p>
								<p style="margin-top: 100px">Nurhayati</p>
							</div>
						</div>	
			</div>
		</div>

	</div>

</div>


</body>
</html>