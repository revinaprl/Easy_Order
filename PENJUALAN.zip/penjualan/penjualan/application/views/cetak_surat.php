<?php

$rs = $data->row();
?>

<!DOCTYPE html>
<html>
<head>
	<base href="<?php echo base_url() ?>">
	<title>Cetak Surat Jalan</title>
	<link rel="stylesheet" type="text/css" href="assets/bootflat-admin/css/bootstrap.min.css">

	
</head>
<body onload="window.print();">
	<div class="container">
	<center>
		<table>
			<tr>
				<td width="70px" rowspan="3"><img src="<?php echo base_url('logo/sap.png') ?>" width='50px'></td>
				<td style="text-align: center;"><h4>CV. SURYA ANUGERAH PLASTIK</h4></td>

			</tr>
			<tr>
				
				<td style="text-align: center;"><p>Jl. Cilalawak, Purwakarta</p></td>
			</tr>
			<tr>
				
				<td style="text-align: center;"><p>Telp. (0821)-612673</p></td>
			</tr>
			
		</table>
		<p style="text-align: right;"><b>SURAT JALAN</b></p>
	</center>
<hr style=" height: 2px; color:black; border-color: black; border-width:3px">
	<div class="row">
		<div class="col-md-12">
			<table class="table">
			
					<tr>
					<th>Kode Surat</th>
					<th>:</th>
					<td><?php echo $rs->kode_surat; ?></td>
				
				</tr>
				<tr>
					<th>No Kendaraan</th>
					<th>:</th>
					<td><?php echo $rs->kd_kd; ?></td> 
				</tr>
				<tr>
					<th>Tanggal Kirim</th>
					<th>:</th>
					<td><?php echo $rs->gtl_kirim; ?></td> 
				</tr>
				<tr>
					<th>Nama Customer</th>
					<th>:</th>
					<td><?php echo $rs->cust_nama; ?></td> 
				</tr>
				<tr>
					<th>No telepon</th>
					<th>:</th>
					<td><?php echo $rs->telp_no; ?></td> 
				</tr>
			</table>
			<table class="table" border="1" >
			<thead>
				<tr>
					<th>No.</th>
					<th>Kode Bareng</th>
					<th>Nama Barang</th>
					<th>Qty Order</th>
					<th>Satuan Barang</th>
					<th>Qty Kirim</th>
					<th>Sisa Order</th>
					
				</tr>
			</thead>
			<tbody>
			<?php 
				$sql = $this->db->query("SELECT b.kode_barang as bkode_barang, b.nama_barang as bnama_barang, dt.qty as dt_qty, dt.satuan as dt_satuan,s.qty_kirim as kirim_qty,s.sisa_order as order_sisa
				FROM transaksi t JOIN detail_transaksi dt ON t.kode_order = dt.kode_order JOIN barang b ON dt.kode_barang = b.kode_barang
			join surat s on s.kode_order = t.kode_order
			WHERE dt.kode_order ='$rs->kode_order'");
			
				$no = 1;
				foreach ($sql->result() as $row) {
				 ?>

				<tr>

					<td><?php echo $no++; ?></td>
					<td><?php echo $row->bkode_barang; ?></td>
					<td><?php echo $row->bnama_barang; ?></td>
					<td><?php echo $row->dt_qty; ?></td>
					<td><?php echo $row->dt_satuan; ?></td>
					<td><?php echo $row->kirim_qty; ?></td>
					<td><?php echo $row->dt_qty - $row->kirim_qty; ?></td>

				</tr>
				<?php } ?>
			</tbody>
		</table>
		<div class="col-md-5 col-md-offset-7" style="margin-top: 400px;">
		<table class="table" style="margin-bottom: 10px; border-width: 3px;" border="1">
			<tr>
				<th style="width: 20px;">Yang Menerima</th>
				<th style="width: 20px;">Dikirim</th>
				<th style="width: 20px;">Hormat Kami</th>
			</tr>
			<tr>
				<td style="height: 100px;"></td>
				<td></td>
				<td></td>
			</tr>
		</table>
	</div>
		<!-- <div class="row">
			<div class="col-lg-6">
			<div class="card" style="width: 18rem;">
				<ul class="list-group list-group-flush">

				<li class="list-group-item" style="margin-left: 871px; padding-bottom: 127px;"><b>Purwarkarta,<?php echo date('d/m/Y') ?></b> </li>
				<li class="list-group-item" style="margin-left: 871px; margin-bottom: 0px; padding-top: 132px; margin-top: -106px;" ><img src="http://localhost/penjualan/logo/ttd.jpg" width="245px" style="margin-top: -126px;"></li>
				<li class="list-group-item" style="margin-left: 871px;">Nurhayati</li>
				</ul>
			</div>
			</div>
			<div class="col-lg-6">
			<div class="card" style="width: 18rem;">
				<ul class="list-group list-group-flush">

				<li class="list-group-item" style=" padding-bottom: 127px;"><b>Purwarkarta,<?php echo date('d/m/Y') ?></b> </li>
				<li class="list-group-item" style=" margin-bottom: 0px; padding-top: 132px; margin-top: -106px;" ><img src="http://localhost/penjualan/logo/ttd.jpg" width="245px" style="margin-top: -126px;"></li>
				<li class="list-group-item">Nurhayati</li>
				</ul>
			</div>
			</div>
		</div> -->
		</div>
	</div>
</div>


</body>
</html>