<!DOCTYPE html>
<html>
<head>
	<base href="<?php echo base_url() ?>">
	<title>Cetak Order</title>
	<link rel="stylesheet" type="text/css" href="assets/bootflat-admin/css/bootstrap.min.css">
</head>
<body onload="window.print();">
	<div class="container">
	<center>
		<table>
			<tr>
				<td width="70px" rowspan="3"><img src="<?php echo base_url('logo/sap.png') ?>" width='50px'></td>
				<td style="text-align: center;"><h4>CV. SURYA ANUGERAH PLASTIK</h4></td>

			</tr>
			<tr>
				
				<td style="text-align: center;"><p>Jl. Cilalawak, Purwakarta</p></td>
			</tr>
			<tr>
				
				<td style="text-align: center;"><p>Telp. (0821)-612673</p></td>
			</tr>
			
		</table>
		<p style="text-align: right;"><b>ORDER</b></p>
	</center>
	<hr style=" height: 2px; color:red;background-color:black">
	<?php 
	$rs = $data->row();
	 ?>
	<div class="row">
		<div class="col-md-12">
			<table class="table">
				<tr>
					<th>Kode Order</th>
					<th>:</th>
					<td><?php echo $rs->kode_order; ?></td>
				</tr>
				<tr>
					<th>Tanggal Order</th>
					<th>:</th>
					<td><?php echo $rs->tgl_order; ?></td>
				</tr>
			</table>
		</div>
		<div class="col-md-12">
			<table class="table table-bordered" style="margin-bottom: 10px" >
				<thead>
					<tr>
						<th>No.</th>
						<th>Kode Barang</th>
						<th>Kategori</th>
						<th>Nama Barang</th>
						<th>Customer</th>
						<th>Qty</th>
						<th>Harga</th>
						<th>Jumlah</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$sql = $this->db->query("SELECT dt.*, c.nama_customer as cust_nama, c.alamat as cust_alamat, c.no_telp as cust_no, b.kategori as kategori_brg, b.nama_barang as nama_brg, b.harga as harga_brg FROM detail_transaksi dt JOIN barang b ON dt.kode_barang = b.kode_barang JOIN customer c ON dt.kode_customer = c.kode_customer WHERE dt.kode_order = '$rs->kode_order'");
					$no = 1;
					foreach ($sql->result() as $row) {
					 ?>
					<tr>
						<td><?php echo $no++; ?></td>
						<td><?php echo $row->kode_barang; ?></td>
						<td><?php echo $row->kategori_brg; ?></td>
						<td><?php echo $row->nama_brg; ?></td>
						<td><?php echo $row->cust_nama; ?></td>
						<td><?php echo $row->qty; ?></td>
						<td><?php echo $row->harga_brg; ?></td>
						<td><?php 
						$totharga = $row->qty*$row->harga;
						echo number_format($totharga);
						 ?></td>
					</tr>
					<?php } ?>
					<tr>
						<td colspan="7">Total Harga</td>
						<td>Rp. <?php echo number_format($rs->total_harga) ?></td>
					</tr>
					<tr>
						<td colspan="7"><b>PPN (10%)</b></td>
						
						<td> Rp.
						<?php 
						$ppn = 0.1 * $rs->total_harga;
						$setelahppn = $rs->total_harga+$ppn;
						
						echo number_format($setelahppn);

						?>
					</tr>
					 <tr>
						<td colspan="7"><b>Diskon</b></td>
						<td>
							Rp.
						<?php 
						$diskon = 0;
						if ($setelahppn >= 100000) {
							$diskon = 0.1 * $setelahppn;
						} else {
							$diskon = 0;
						 
						}
						echo number_format($diskon);

						?>
						</td>
					</tr>
					<tr>
						<td colspan="7"><b>Total Bayar</b></td>
						<td>Rp. <?php echo number_format($setelahppn-$diskon) ?></td>
					</tr>
					
				</tbody>
			</table>
<div class="col-md-5 col-md-offset-7" style="margin-top: 200px;">
		<table class="table" style="margin-bottom: 10px; border-width: 3px;" border="1">
			<tr>
				<th style="width: 40px;">Customer</th>
				<th style="width: 40px;">Dibuat</th>
				<th style="width: 40px;">Diperiksa</th>
				<th style="width: 40px;">Disetujui</th>
			</tr>
			<tr>
				<td style="height: 100px;"></td>
				<td></td>
				<td></td>
			</tr>
		</table>
	</div>
		</div>
	</div>
</div>
</body>
</html>