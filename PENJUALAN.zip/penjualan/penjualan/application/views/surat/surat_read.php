<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Surat Read</h2>
        <table class="table">
	    <tr><td>Kode Surat</td><td><?php echo $kode_surat; ?></td></tr>
        <tr><td>Nama Barang</td><td><?php echo $nama_barang; ?></td></tr>
        <tr><td>No Kendaraan</td><td><?php echo $no_kendaraan; ?></td></tr>
        <tr><td>Tanggal Kirim</td><td><?php echo $tgl_kirim; ?></td></tr>
	    <tr><td>Qty Order</td><td><?php echo $qty_order; ?></td></tr>
        <tr><td>Qty Kirim</td><td><?php echo $qty_kirim; ?></td></tr>
        <tr><td>Sisa Order</td><td><?php echo $sisa_order; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('surat') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>