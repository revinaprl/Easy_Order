<form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="varchar">Kode Surat <?php echo form_error('kode_surat') ?></label>
            <input type="text" class="form-control" name="kode_surat" id="kode_surat" placeholder="Kode Surat" value="<?php echo $kode_surat; ?>" />
        </div>
        <div class="form-group">
            <label for="int">Nama Barang <?php echo form_error('no_po') ?></label>
            <input type="text" class="form-control" name="nama_barang" id="nama_barang" placeholder="Nama Barang" value="<?php echo $nama_barang; ?>" />
        </div>
         <div class="form-group">
            <label for="int">No Kendaraan <?php echo form_error('no_kendaraan') ?></label>
            <input type="text" class="form-control" name="no_kendaraan" id="no_kendaraan" placeholder="No Kendaraan" value="<?php echo $no_kendaraan; ?>" />
        </div>
        <div class="form-group">
            <label for="int">Tanggal Kirim <?php echo form_error('tgl_kirim') ?></label>
            <input type="text" class="form-control" name="tgl_kirim" id="tgl_kirim" placeholder="Tanggal Kirim" value="<?php echo $tgl_kirim; ?>" />
        </div>
        <div class="form-group">
            <label for="varchar">Qty Order <?php echo form_error('qty_order') ?></label>
            <input type="text" class="form-control" name="qty_order" id="qty_order" placeholder="Qty Order" value="<?php echo $qty_order; ?>" />
        </div>
        <div class="form-group">
            <label for="varchar">Qty Kirim <?php echo form_error('qty_kirim') ?></label>
            <input type="text" class="form-control" name="qty_kirim" id="qty_kirim" placeholder="Qty Kirim" value="<?php echo $qty_kirim; ?>" />
        </div>
        <div class="form-group">
            <label for="varchar">Sisa Order <?php echo form_error('sisa_order') ?></label>
            <input type="text" class="form-control" name="sisa_order" id="sisa_order" placeholder="Sisa Order" value="<?php echo $sisa_order; ?>" />
        </div>
        <input type="hidden" name="id_surat" value="<?php echo $id_surat; ?>" /> 
        <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
        <a href="<?php echo site_url('surat') ?>" class="btn btn-default">Cancel</a>
    </form>