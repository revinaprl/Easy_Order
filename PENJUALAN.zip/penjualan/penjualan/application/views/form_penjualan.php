<?php
//notifikasi
if ($this->session->flashdata('error')) {
    echo '<p class="alert alert-success text-center">';
    echo $this->session->flashdata('error');
    echo '</p>';
}
?>

<div class="row">
	<div class="col-md-12">
	<form action="app/simpan_penjualan" method="POST">
		<div class="form-group">
            <label>Kode Order </label>
            <input type="text" class="form-control" name="kode_order" id="kode_order" value="<?php echo $kodeurut; ?>" readonly/>
        </div>
        <div class="form-group">
            <label>Tanggal Order</label>
            <input class="form-control" type="date" id="tgl_transaksi" name="tgl_transaksi" value="<?php echo date("d-m-Y") ?>" required>
        </div>
	<div class="form-group">
            <label>Kode Surat </label>
            <input type="text" class="form-control" name="kode_surat" id="kode_surat" value="<?php echo $kode_surat; ?>" readonly/>
        </div>
        <div class="form-group">
            <label>Customer </label>
            <select class="form-control" id="nama_customer" name="nama_customer" required>
                        <option value="">--Pilih Customer--</option>
            <?php 
            $sql = $this->db->get('customer');
            foreach ($sql->result() as $row) {
             ?>
            <option value="<?php echo $row->kode_customer ?>"><?php echo $row->nama_customer ?></option>
            <?php } ?>
                    </select>
        </div>
        <div class="table-resposive">
        <table class="table table-bordered">
        	<tr>
        		<th>No.</th>
                <th>Kode Barang</th>
                <th>Kategori</th>
                <th>Nama Barang</th>
                <th>Qty Order</th>
                <th>Satuan</th>
                <th>Harga Barang</th>
        		<th>Subtotal</th>
        		<th>
        			<!-- Trigger the modal with a button -->
					<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">Tambah Order</button>
        		</th>
        	</tr>
        	<tr>
            <?php $i=1; $no=1;?>
            <?php foreach($this->cart->contents() as $items): ?>
                <td><?php echo $no; ?></td>
                <td><?php echo $items['id']; ?></td>
                <td><?php echo $items['category']; ?></td>
                <td><?php echo $items['name']; ?></td>
                <td><?php echo $items['qty']; ?></td>
                <td><?php echo $items['satuan']; ?></td>
                
                <td>Rp. <?php echo $this->cart->format_number($items['price']); ?></td>
                <td>Rp. <?php echo $this->cart->format_number($items['subtotal']); ?></td>
                <td>
                    <a href="app/hapus_cart/<?php echo $items['rowid'] ?>" class="btn btn-warning btn-sm">X</a>
                </td>
            </tr>
            <?php $i++; $no++;?>
            <?php endforeach; ?>
            <tr>
                <th colspan="5">Total Harga</th>
                <th colspan="2">Rp. <?php echo $this->cart->format_number($this->cart->total()); ?></th>
            </tr>
            <tr>
                <th colspan="7"><b>PPN (10%)</b></th>
                <th colspan="2"> Rp. <?php 
                $total_harga = $this->cart->total();

                    $ppn = 0.1 * $total_harga;
                    $setelahppn = $total_harga+$ppn;
                        
                    echo number_format($setelahppn);

                    ?>
            </tr>
            <tr>
                <th colspan="7"><b>Diskon</b></td>
                <th colspan="2">
                    Rp.
                    <?php 
                    $diskon = 0;
                    if ($setelahppn >= 100000) {
                        $diskon = 0.1 * $setelahppn;
                        } else {
                            $diskon = 0;
                         
                        }
                        echo number_format($diskon);

                        ?>
                        </th>
                    </tr>
                    <tr>
                        <th colspan="7"><b>Total Bayar</b></th>
                        <th colspan="2"> Rp. <?php echo number_format($setelahppn-$diskon) ?></th>
                    </tr>
        </table>
        </div>
        <div class="form-group">
            <input type="hidden" name="total_harga" value="<?php echo $this->cart->total() ?>">
            
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="app/penjualan" class="btn btn-default">Close</a>
        </div>        	
	</form>
	</div>
</div>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <form action="App/simpan_cart" method="POST">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Tambah Order</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
            <label>Nama Barang</label><br>
          <select id="nama_barang" name="nama_barang"  class="form-control" required>
            <option value="">--Pilih Barang--</option>
            <?php 
            $sql = $this->db->get('barang');
            foreach ($sql->result() as $row) {
             ?>s
            <option value="<?php echo $row->kode_barang; ?>"><?php echo $row->nama_barang ?></option>
            <?php } ?>
          </select>
        </div>
        
            
        
        <div class="form-group">
            <label>Kode Barang</label>
            <input type="text" class="form-control" name="kode_barang" id="kode_barang" readonly/>
        </div>
        <div class="form-group">
            <label>Kategori </label>
            <input type="text" class="form-control" name="kategori" id="kategori" readonly/>
        </div>
        <div class="form-group">
            <label>Stok </label>
            <input type="text" class="form-control" name="stok" id="stok" readonly/>
        </div>
        <div class="form-group">
            <label>Harga Barang </label>
            <input type="text" class="form-control" name="harga" id="harga" readonly/>
        </div>
        <div class="form-group">
            <label>Satuan </label>
            <select id="nama_satuan" name="satuan"  class="form-control" required>
            <option value="">--Pilih Satuan--</option>
            <?php 
            $sql = $this->db->get('satuan');
            foreach ($sql->result() as $row) {
             ?>
            <option value="<?php echo $row->nama_satuan ?>"><?php echo $row->nama_satuan ?></option>
            <?php } ?>
          </select>
        </div>
        <div class="form-group">
            <label>Jumlah Order </label>
            <input type="text" class="form-control" name="jumlah_order" id="jumlah_order" required />
        </div>
      </div>
      <div class="modal-footer">
        <input type="hidden" class="form-control" name="nabar" id="nabar"/>
      	<input type="submit" class="btn btn-info" name="submit" value="Simpan">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
    </form>

  </div>
</div>  

<script type="text/javascript">
  $(document).ready(function(){
    $('#nama_barang').change(function() {
      var id = $(this).val();
      $.ajax({
        type : 'POST',
        url : '<?php echo base_url('app/cek_barang') ?>',
        Cache : false,
        dataType: "json",
        data : 'kode_barang='+id,
        success : function(resp) {
             //$('.nama').val(resp.nama);
            $('#kode_barang').val(resp.kode_barang);
            $('#kategori').val(resp.kategori);
            $('#stok').val(resp.stok); 
            $('#harga').val(resp.harga); 
            $('#satuan').val(resp.satuan);
            $('#qty').val(resp.qty); 
            $('#nabar').val(resp.nama_barang); 
        }
      });
      alert(id);
    });


    
  });
</script>