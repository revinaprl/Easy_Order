<?php 
$rs = $data->row();
 ?>
<div class="row">
	<div class="col-md-12">
		<table class="table">
			<tr>
				<th>Kode Surat</th>
				<th>:</th>
				<td><?php echo $rs->kode_surat; ?></td>
			
			</tr>
			<tr>
				<th>No Kendaraan</th>
				<th>:</th>
				<td><?php echo $rs->kd_kd; ?></td> 
			</tr>
			<tr>
				<th>Tanggal Kirim</th>
				<th>:</th>
				<td><?php echo $rs->gtl_kirim; ?></td> 
			</tr>
			<tr>
				<th>Nama Customer</th>
				<th>:</th>
				<td><?php echo $rs->cust_nama; ?></td> 
			</tr>
			<tr>
				<th>No telepon</th>
				<th>:</th>
				<td><?php echo $rs->telp_no; ?></td> 
			</tr>
			
		</table>
	</div>
	<div class="col-md-12">
		<table class="table table-bordered" style="margin-bottom: 10px" >
			<thead>
				<tr>
					<th>No.</th>
					<th>Kode Bareng</th>
					<th>Nama Barang</th>
					<th>Qty Order</th>
					<th>Satuan Barang</th>
					<th>Qty Kirim</th>
					<th>Sisa Order</th>
					
				</tr>
			</thead>
			<tbody>
			<?php 
				$sql = $this->db->query("SELECT b.kode_barang as bkode_barang, b.nama_barang as bnama_barang, dt.qty as dt_qty, dt.satuan as dt_satuan,s.qty_kirim as kirim_qty,s.sisa_order as order_sisa
				FROM transaksi t JOIN detail_transaksi dt ON t.kode_order = dt.kode_order JOIN barang b ON dt.kode_barang = b.kode_barang
			join surat s on s.kode_order = t.kode_order
			WHERE dt.kode_order ='$rs->kode_order'
				");
			
				$no = 1;
				foreach ($sql->result() as $row) {
				 ?>

				<tr>

					<td><?php echo $no++; ?></td>
					<td><?php echo $row->bkode_barang; ?></td>
					<td><?php echo $row->bnama_barang; ?></td>
					<td><?php echo $row->dt_qty; ?></td>
					<td><?php echo $row->dt_satuan; ?></td>
					<td><?php echo $row->kirim_qty; ?></td>
					<td><?php echo $row->dt_qty - $row->kirim_qty; ?></td>

				</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
</div>