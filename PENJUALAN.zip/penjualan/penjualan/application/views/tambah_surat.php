<div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4"></div><br><br><br>
    <div class="col-md-12">
        <form role="form" id="frmTbh">
            <div class="form-group">
                <label class="col-lg-4">Kode Surat</label>
                <div class="col-lg-8">
                    <input type="text" class="form-control" name="kode_surat" id="kode_surat" value="<?php echo $kodeurut; ?>" readonly/>
                </div>
            </div>
            <div class="form-group">
                <label class="col-lg-4">No. Kendaraan</label>
                <div class="col-lg-8">
                    <input type="text" class="form-control" name="no_kendaraan" id="no_kendaraan"readonly/>
                </div>
            </div>
            <div class="form-group">
                <label class="col-lg-4">Tanggal Kirim</label>
                <div class="col-lg-8">
                    <input class="form-control" type="text" id="tgl_kirim" name="tgl_kirim" value="<?php echo date("Y-m-d") ?>" >
                </div>
            </div>
            <div class="form-group">
                <label class="col-lg-4">Qty Kirim</label>
                <div class="col-lg-8">
                    <input type="text" class="form-control" name="qty_kirim" id="qty_kirim">
                </div>
            </div>
            <div class="form-group">
                <label class="col-lg-4">Kode Order</label>
                <div class="col-lg-8">
                    <select class="form-control" id="kode_order" name="kode_order">
                        <option value="">--Customer--</option>
                        <?php
                            $dt = $this->db->query("select * from transaksi")->result();
                            foreach ($t as $data_t)
                            {
                                ?>
                                <option value="<?php echo $data_dt->kode_order ?>"><?php echo $data_t->kode_order ?> - <?php echo $data_t->nama_customer ?></option>
                                <?php
                            }
                        ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="col-lg-4">Nama Barang</label>
                <div class="col-lg-8">
                    <input class="form-control" type="text" id="nama_barang" name="nama_barang" readonly/>
                </div>
            </div>
            <div class="form-group">
                <label class="col-lg-4">Qty Order</label>
                <div class="col-lg-8">
                    <input class="form-control" type="text" id="qty" name="qty" readonly/>
                </div>
            </div>
            <div class="form-group">
                <label class="col-lg-4">Sisa Order</label>
                <div class="col-lg-8">
                    <input class="form-control" type="text" id="sisa_order" name="sisa_order">
                </div>
            </div>
            <div class="form-group">
                <label class="col-lg-4"></label>
                <div class="col-lg-8">
                    <button type="submit" id="btnSimpanDtl" class="btn btn-success">Simpan</button>
                </div>
            </div>
        </form>
    </div>
    
<script type="text/javascript">
    $(document).ready(function() {

        $("#btnSimpan").click(function() {
            $("#frmTbh").validate({
                rules: {
                    kode_surat: {
                        required: true
                    },
                    no_kendaraan: {
                        required: true
                    },
                    tgl_kirim: {
                        required: true
                        date: true
                    },
                     qty_kirim: {
                        required: true,
                        number: true
                    },
                    kode_order: {
                        required: true,
                    },
                },
                messages: {
                    kode_surat: {
                        required: "Kode Surat Harus Diisi"
                    },
                    no_kendaraan: {
                        required: "No Kendaraan Harus Diisi"
                    },
                    tgl_kirim: {
                        required: "Tanggal Kirim Harus Diisi"
                        date: true
                    },
                    qty_kirim: {
                        required: "Qty Kirim Harus Diisi"
                        number: true
                    },
                    kode_order: {
                        required: "Kode Order Harus Diisi",
                    },
                },
                submitHandler: function(form) {
                    $.ajax({
                        type: "post",
                        url: "<?php echo base_url() ?>surat/simpan_surat",
                        dataType: "text",
                        data: $("#frmTbh").serialize(),
                        cache: false,
                        success: function(data)
                        {
                            var header = data.split("\t");
                            switch(header[0])
                            {
                                case 'OK':
                                    swal("Success", "Berhasil", "success").then(function() {
                                        $("#detailSurat").show();
                                        $("#btnSimpan").hide();
                                    });
                                    break;
                                case 'udad':
                                    swal("Gagal", "Kode Surat Sudah Terdaftar. Silahkan Refresh Terlebih Dahulu", "error").then(function() {
                                        location.reload();
                                    });
                                    break;
                                case 'errkend':
                                    swal("Gagal", "No Kendaraan Sudah Terdaftar. Silahkan Refresh Terlebih Dahulu", "error").then(function() {
                                        $("#kend").focus().select();
                                    });
                                    break;
                                case 'errtglki':
                                    swal("Gagal", "Tanggal Kirim Sudah Terdaftar. Silahkan Refresh Terlebih Dahulu", "error").then(function() {
                                        $("#tglki").focus().select();
                                    });
                                    break;
                                case 'errqtyki':
                                    swal("Gagal", "Qty Kirim Sudah Terdaftar. Silahkan Refresh Terlebih Dahulu", "error").then(function() {
                                        $("#qtyki").focus().select();
                                    });
                                    break;
                                default:
                                    swal("Gagal", header[0], "error");
                            }
                        }
                    });
                }
            });
        });

        
                            }
</script>