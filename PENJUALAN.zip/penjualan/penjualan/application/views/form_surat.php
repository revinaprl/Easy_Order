<div class="container-fluid">

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h2 class="h3 mb-0 text-gray-800 text-center">INVOICE</h2>
    <a class="btn btn-danger mb-3" href="<?php echo base_url('invoice/cetak_invoice') ?>"> <i class="fa fa-print"></i> Print</a>
  </div>


  <div class="form-group">
            <label>Kode Invoice </label>
            <input type="text" class="form-control" name="kode_invoice" id="kode_invoice" value="<?php echo $kodeurut; ?>" readonly/>
        </div>
  
  <h3 class="card-title">Data Order</h3>
  <div class="container-fluid">

    <table class="table table-bordered">
      <tr class="text-center">
        <th class="col-lg-1">No.</th>
        <th class="col-sm-4">Nama Barang</th>
        <th class="col-sm-4">Jumlah Barang</th>
        <th class="col-sm-4">Satuan</th>
        <th class="col-sm-4">Harga Barang</th>
        <th class="col-sm-4">Total Harga</th>
      </tr>
      <?php
      $no = 1;
      foreach ($detail_transaksi as $detail_transaksi) {
      ?>
        <tr class="text-center">

          <td><?php echo $no++ ?></td>
          <td><?php echo $detail_transaksi->nama_barang ?></td>
          <td><?php echo $detail_transaksi->qty ?></td>
          <td><?php echo $detail_transaksi->satuan ?></td>
          <td><?php echo $detail_transaksi->harga ?></td>
          <td><?php echo $detail_transaksi->total_harga ?></td>
        </tr>
      <?php  } ?>


    </table>
  </div>