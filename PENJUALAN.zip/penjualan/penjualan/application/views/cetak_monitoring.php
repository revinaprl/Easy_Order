<!DOCTYPE html>
<html>
<head>
	<base href="<?php echo base_url() ?>">
	<title>Cetak Monitoring</title>
	<link rel="stylesheet" type="text/css" href="assets/bootflat-admin/css/bootstrap.min.css">

	
</head>
<body onload="window.print();">
	<div class="container">
	<center>
		<table>
			<tr>
				<td width="70px" rowspan="3"><img src="<?php echo base_url('logo/sap.png') ?>" width='50px'></td>
				<td style="text-align: center;"><h4>CV. SURYA ANUGERAH PLASTIK</h4></td>

			</tr>
			<tr>
				
				<td style="text-align: center;"><p>Jl. Cilalawak, Purwakarta</p></td>
			</tr>
			<tr>
				
				<td style="text-align: center;"><p>Telp. (0821)-612673</p></td>
			</tr>
			
		</table>
		<p style="text-align: right;"><b>MONITORING</b></p>
	</center>
<hr style=" height: 2px; color:black; border-color: black; border-width:3px">
	<div class="row">
		<div class="col-md-12">
			<table class="table">
				<?php
					foreach ($data as $data_cetak)
					{
						?>
						<tr>
							<th>Nama Customer</th>
							<th>:</th>
							<td><?php echo $data_cetak->kode_customer; ?></td>
							
						</tr>
						<?php
					}
				?>
			</table>
			<table class="table" border="1" >
			<thead>
				<tr>
					<th>No.</th>
        <th>Kode Monitoring</th>
        <th>Kode Order</th>
        <th>Kode Customer</th>
        <th>Kode Barang</th>
        <th>Tanggal Order</th>
        <th>Tanggal Kirim</th>
        <th>Qty Order</th>
        <th>Qty Kirim</th>
        <th>Status</th>
            </tr>
			</thead>
			<tbody>
			<tr>
					<td><?php echo $no++; ?></td>	
            <td><?php echo $data_cetak->kode_monitoring ?></td>
            <td><?php echo $data_cetak->kode_order ?></td>
            <td><?php echo $data_cetak->kode_customer ?></td>
            <td><?php echo $data_cetak->kode_barang ?></td>
             <td><?php echo $data_cetak->tgl_order ?></td>
            <td><?php echo $data_cetak->tgl_kirim ?></td>
            <td><?php echo $data_cetak->qty_order ?></td>
            <td><?php echo $data_cetak->qty_kirim ?></td>
            <td><?php echo $data_cetak->status ?></td>
						</tr>
				
			</tbody>
		</table>
		
		<!-- <div class="row">
			<div class="col-lg-6">
			<div class="card" style="width: 18rem;">
				<ul class="list-group list-group-flush">

				<li class="list-group-item" style="margin-left: 871px; padding-bottom: 127px;"><b>Purwarkarta,<?php echo date('d/m/Y') ?></b> </li>
				<li class="list-group-item" style="margin-left: 871px; margin-bottom: 0px; padding-top: 132px; margin-top: -106px;" ><img src="http://localhost/penjualan/logo/ttd.jpg" width="245px" style="margin-top: -126px;"></li>
				<li class="list-group-item" style="margin-left: 871px;">Nurhayati</li>
				</ul>
			</div>
			</div>
			<div class="col-lg-6">
			<div class="card" style="width: 18rem;">
				<ul class="list-group list-group-flush">

				<li class="list-group-item" style=" padding-bottom: 127px;"><b>Purwarkarta,<?php echo date('d/m/Y') ?></b> </li>
				<li class="list-group-item" style=" margin-bottom: 0px; padding-top: 132px; margin-top: -106px;" ><img src="http://localhost/penjualan/logo/ttd.jpg" width="245px" style="margin-top: -126px;"></li>
				<li class="list-group-item">Nurhayati</li>
				</ul>
			</div>
			</div>
		</div> -->
		<div class="col-md-6 text-left">
								<p>Purwakarta, <?php echo date('d/m/Y') ?></p>
								<p style="margin-top: 100px">Nurhayati</p>
							</div>	
		</div>
	</div>
</div>


</body>
</html>