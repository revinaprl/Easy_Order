<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Kwitansi Read</h2>
        <table class="table">
        <tr><td>Kode Kwitansi</td><td><?php echo $kode_kwitansi; ?></td></tr>
        <tr><td>Kode Order</td><td><?php echo $kode_order; ?></td></tr>
         <tr><td>Nama Penerima</td><td><?php echo $nama_penerima?></td></tr>
        <tr><td>Banyak Uang</td><td><?php echo $banyak_uang; ?></td></tr>
	    <tr><td>Jumlah Uang</td><td><?php echo $jumlah_uang; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('kwitansi') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>