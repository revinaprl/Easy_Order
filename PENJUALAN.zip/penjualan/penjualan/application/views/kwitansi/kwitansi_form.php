<form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data">
         <div class="form-group">
            <label for="int">Kode Kwitansi <?php echo form_error('kode_kwitansi') ?></label>
            <input type="text" class="form-control" name="kode_kwitansi" id="kode_kwitansi" placeholder="Kode Kwitansi" value="<?php echo $kode_kwitansi; ?>" />
        </div>
         <div class="form-group">
            <label for="int">Kode Order <?php echo form_error('kode_invoice') ?></label>
            <input type="text" class="form-control" name="kode_order" id="kode_order" placeholder="Kode Order" value="<?php echo $kode_order; ?>" />
        </div>
        <div class="form-group">
            <label for="int">Nama Penerima <?php echo form_error('nama_penerima') ?></label>
            <input type="text" class="form-control" name="nama_penerima" id="nama_penerima" placeholder="Nama Penerima" value="<?php echo $nama_penerima; ?>" />
        </div>
        <div class="form-group">
            <label for="int">Banyak Uang <?php echo form_error('banyak_uang') ?></label>
            <input type="text" class="form-control" name="banyak_uang" id="banyak_uang" placeholder="Banyak Uang" value="<?php echo $banyak_uang; ?>" />
        </div>
        <div class="form-group">
            <label for="varchar">Jumlah Uang <?php echo form_error('jumlah_uang') ?></label>
            <input type="text" class="form-control" name="jumlah_uang" id="jumlah_uang" placeholder="Jumlah Uang" value="<?php echo $jumlah_uang; ?>" />
        </div>
        <input type="hidden" name="id_kwitansi" value="<?php echo $id_kwitansi; ?>" /> 
        <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
        <a href="<?php echo site_url('kwitansi') ?>" class="btn btn-default">Cancel</a>
    </form>