<div class="row" style="margin-bottom: 10px">
            <div class="col-md-4">
                <?php 
                if ($this->session->userdata('level') == 'admin') {
                 
                echo anchor(site_url('kwitansi/create'),'Tambah Kwitansi', 'class="btn btn-primary"'); 
                }elseif ($this->session->userdata('level') == 'petugas') {
                    echo '';
                }
                ?>
            </div>

        
        <table class="table table-bordered" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
        <th>Kode Kwitansi</th>
        <th>Kode Order</th>
        <th>Nama Penerima</th>
        <th>Banyak Uang</th>
        <th>Jumlah Uang</th>
        <th>Pilihan</th>
            </tr><?php
            foreach ($kwitansi_data as $kwitansi)
            {
                ?>
                <tr>
            <td width="80px"><?php echo ++$start ?></td>
            <td><?php echo $kwitansi->kode_kwitansi ?></td>
            <td><?php echo $kwitansi->kode_order ?></td>
             <td><?php echo $kwitansi->nama_penerima ?></td>
            <td><?php echo $kwitansi->banyak_uang ?></td>
            <td><?php echo $kwitansi->jumlah_uang ?></td>
            <td style="text-align:center" width="300px">
                <?php
                 
                if ($this->session->userdata('level') == 'admin') {
                 
                
                echo anchor(base_url('kwitansi/detail_kwitansi?kode_kwitansi='.$kwitansi->kode_kwitansi),'<button class="btn btn-danger"> <i class="fa fa-eye"></i></button>');
                echo ' | '; 
                echo anchor(base_url('kwitansi/cetak_kwitansi?kode_kwitansi='.$kwitansi->kode_kwitansi),'<button class="btn btn-warning" > <i class="fa fa-print"></i></button>');
                //echo ' | '; 
                //echo anchor(site_url('kwitansi/update/'.$kwitansi->id_kwitansi),'<button class="btn btn-success" > <i class="fa fa-edit"></i></button>'); 
        
                }elseif ($this->session->userdata('level') == 'petugas') {
                echo anchor(base_url('kwitansi/detail_kwitansi?kode_kwitansi='.$kwitansi->kode_kwitansi),'<button class="btn btn-danger"> <i class="fa fa-eye"></i></button>');
                echo ' | '; 
                echo anchor(base_url('kwitansi/cetak_kwitansi?kode_kwitansi='.$kwitansi->kode_kwitansi),'<button class="btn btn-warning" > <i class="fa fa-print"></i></button>');
                
                }
                ?>
            </td>
        </tr>
                <?php
            }
            ?>
        </table>
        <div class="row">
            <div class="col-md-6">
                <a href="#" class="btn btn-primary">Total Record : <?php echo $total_rows ?></a>
        </div>
            <div class="col-md-6 text-right">
                <?php echo $pagination ?>
            </div>
        </div>